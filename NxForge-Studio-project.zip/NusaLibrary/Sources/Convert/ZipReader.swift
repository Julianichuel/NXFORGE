import Foundation

struct ZipEntry {
    let name: String
    let method: UInt16
    let compressedSize: UInt64
    let uncompressedSize: UInt64
    let localHeaderOffset: UInt64
}

enum ZipError: LocalizedError {
    case invalid(String)
    var errorDescription: String? {
        switch self { case .invalid(let m): return "Zip invalido: \(m)" }
    }
}

/// Lector minimo de zip (con ZIP64) para el artefacto de GitHub, que va sin comprimir.
final class ZipReader {
    private let handle: FileHandle
    private let fileSize: UInt64

    init(url: URL) throws {
        let h = try FileHandle(forReadingFrom: url)
        let size = try h.seekToEnd()
        handle = h
        fileSize = size
    }
    deinit { try? handle.close() }

    private func read(at offset: UInt64, count: Int) throws -> Data {
        try handle.seek(toOffset: offset)
        guard let d = try handle.read(upToCount: count), d.count == count else { throw ZipError.invalid("lectura incompleta") }
        return Data(d)   // reinicia los indices en 0
    }
    private func u16(_ d: Data, _ o: Int) -> UInt16 { UInt16(d[o]) | UInt16(d[o + 1]) << 8 }
    private func u32(_ d: Data, _ o: Int) -> UInt32 { UInt32(u16(d, o)) | UInt32(u16(d, o + 2)) << 16 }
    private func u64(_ d: Data, _ o: Int) -> UInt64 { UInt64(u32(d, o)) | UInt64(u32(d, o + 4)) << 32 }

    func entries() throws -> [ZipEntry] {
        let tailLen = Int(min(fileSize, 70_000))
        let tailStart = fileSize - UInt64(tailLen)
        let tail = try read(at: tailStart, count: tailLen)

        var eocd = -1
        var i = tailLen - 22
        while i >= 0 {
            if tail[i] == 0x50, tail[i + 1] == 0x4B, tail[i + 2] == 0x05, tail[i + 3] == 0x06 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { throw ZipError.invalid("no se encontro el final del zip") }

        var total = UInt64(u16(tail, eocd + 10))
        var cdSize = UInt64(u32(tail, eocd + 12))
        var cdOffset = UInt64(u32(tail, eocd + 16))

        if total == 0xFFFF || cdSize == 0xFFFF_FFFF || cdOffset == 0xFFFF_FFFF {
            guard eocd >= 20, tail[eocd - 20] == 0x50, tail[eocd - 19] == 0x4B, tail[eocd - 18] == 0x06, tail[eocd - 17] == 0x07 else {
                throw ZipError.invalid("falta el indicador ZIP64")
            }
            let eocd64Offset = u64(tail, eocd - 20 + 8)
            let rec = try read(at: eocd64Offset, count: 56)
            guard u32(rec, 0) == 0x0606_4B50 else { throw ZipError.invalid("registro ZIP64 danado") }
            total = u64(rec, 32)
            cdSize = u64(rec, 40)
            cdOffset = u64(rec, 48)
        }
        guard cdSize < 64 * 1024 * 1024 else { throw ZipError.invalid("directorio demasiado grande") }
        let cd = try read(at: cdOffset, count: Int(cdSize))

        var result: [ZipEntry] = []
        var p = 0
        for _ in 0..<total {
            guard p + 46 <= cd.count, u32(cd, p) == 0x0201_4B50 else { throw ZipError.invalid("entrada danada") }
            let method = u16(cd, p + 10)
            var comp = UInt64(u32(cd, p + 20))
            var uncomp = UInt64(u32(cd, p + 24))
            let nameLen = Int(u16(cd, p + 28)), extraLen = Int(u16(cd, p + 30)), commentLen = Int(u16(cd, p + 32))
            var local = UInt64(u32(cd, p + 42))
            let nameEnd = p + 46 + nameLen
            guard nameEnd + extraLen + commentLen <= cd.count else { throw ZipError.invalid("entrada truncada") }
            let name = String(decoding: cd[(p + 46)..<nameEnd], as: UTF8.self)

            // Campo extra ZIP64 (id 0x0001): trae, en orden, los valores que valian 0xFFFFFFFF.
            var q = nameEnd
            let extraEnd = nameEnd + extraLen
            while q + 4 <= extraEnd {
                let id = u16(cd, q), size = Int(u16(cd, q + 2))
                if id == 0x0001 {
                    var f = q + 4
                    if uncomp == 0xFFFF_FFFF { uncomp = u64(cd, f); f += 8 }
                    if comp == 0xFFFF_FFFF { comp = u64(cd, f); f += 8 }
                    if local == 0xFFFF_FFFF { local = u64(cd, f); f += 8 }
                }
                q += 4 + size
            }
            result.append(ZipEntry(name: name, method: method, compressedSize: comp, uncompressedSize: uncomp, localHeaderOffset: local))
            p = extraEnd + commentLen
        }
        return result
    }

    /// Donde empiezan y cuanto miden los datos de una entrada.
    func dataRange(of entry: ZipEntry) throws -> (offset: UInt64, length: UInt64) {
        let h = try read(at: entry.localHeaderOffset, count: 30)
        guard u32(h, 0) == 0x0403_4B50 else { throw ZipError.invalid("cabecera local danada") }
        let start = entry.localHeaderOffset + 30 + UInt64(u16(h, 26)) + UInt64(u16(h, 28))
        return (start, entry.compressedSize)
    }
}
