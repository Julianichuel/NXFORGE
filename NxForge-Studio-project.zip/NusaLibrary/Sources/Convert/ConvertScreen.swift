import SwiftUI
import UIKit

struct ConvertScreen: View {
    @EnvironmentObject private var keys: KeyStore
    @EnvironmentObject private var log: LogStore
    @StateObject private var model = ConvertModel()
    @State private var urls = ""
    @State private var profile: MemoryProfile = .gb6
    @State private var showSettings = false
    @State private var keysCopied = false
    let theme: AppTheme

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Convertir NSP a IPA").font(.headline)
                Spacer()
                Button { showSettings.toggle() } label: {
                    Image(systemName: "gearshape.fill").font(.headline)
                        .frame(width: 40, height: 40).background(Palette.field.opacity(0.8), in: Circle())
                }.buttonStyle(PillButtonStyle())
            }
            Text("GitHub hace la conversion en una Mac. Esta app solo la pide, espera y baja el IPA.")
                .font(.footnote).foregroundStyle(.secondary)

            if !model.isConfigured || showSettings { settingsBox }
            inputBox
            statusBox
        }
        .onAppear { model.log = log }
    }

    // MARK: Ajustes

    private var settingsBox: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Ajustes").font(.subheadline.weight(.semibold))
            HStack(spacing: 8) {
                field("Usuario de GitHub", text: $model.owner)
                field("Repositorio", text: $model.repo)
            }
            secureField("Token de GitHub (Actions: lectura y escritura)", text: $model.token)
            secureField("Contrasena (la misma del secreto ARTIFACT_PASSWORD)", text: $model.password)

            Button {
                model.saveSettings()
            } label: { smallLabel("Guardar ajustes", "checkmark.circle.fill") }
            .buttonStyle(PillButtonStyle())

            Button {
                if let b64 = keys.exportBase64() { UIPasteboard.general.string = b64; keysCopied = true }
            } label: { smallLabel(keysCopied ? "Copiado: pegalo en el secreto PROD_KEYS_B64" : "Copiar mis keys para el secreto PROD_KEYS_B64", "key.fill") }
            .buttonStyle(PillButtonStyle())
            .disabled(keys.keyCount == 0)

            Text("Las keys se copian al portapapeles solo para pegarlas en GitHub (Settings > Secrets > Actions). No se muestran en pantalla.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .padding(12)
        .background(Palette.field.opacity(0.5), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: Pedido

    private var inputBox: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Enlaces directos al juego (uno por linea: base y, si tienes, la actualizacion)")
                .font(.footnote).foregroundStyle(.secondary)
            ZStack(alignment: .topLeading) {
                TextEditor(text: $urls)
                    .scrollContentBackground(.hidden)
                    .font(.system(.footnote, design: .monospaced))
                    .autocorrectionDisabled().textInputAutocapitalization(.never)
                    .frame(minHeight: 84)
                    .padding(6)
                if urls.isEmpty {
                    Text("https://...").font(.system(.footnote, design: .monospaced))
                        .foregroundStyle(.secondary).padding(14).allowsHitTesting(false)
                }
            }
            .background(Palette.field.opacity(0.7), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

            HStack {
                Text("Mi iPhone").font(.footnote).foregroundStyle(.secondary)
                Spacer()
                Picker("Mi iPhone", selection: $profile) {
                    ForEach(MemoryProfile.allCases) { Text($0.title).tag($0) }
                }.pickerStyle(.menu)
            }

            if model.isBusy {
                Button(role: .destructive) { model.cancel() } label: { bigLabel("Cancelar", "stop.fill") }
                    .buttonStyle(PillButtonStyle())
            } else {
                Button { model.start(urlsText: urls, profile: profile) } label: { bigLabel("Iniciar conversion", "arrow.triangle.2.circlepath") }
                    .buttonStyle(PillButtonStyle())
                Button { model.resumeLatest() } label: { smallLabel("Retomar la ultima ejecucion", "arrow.counterclockwise") }
                    .buttonStyle(PillButtonStyle())
            }
        }
    }

    // MARK: Estado

    @ViewBuilder
    private var statusBox: some View {
        if model.phase != .idle {
            VStack(alignment: .leading, spacing: 10) {
                Text(model.message)
                    .font(.system(.footnote, design: .monospaced))
                    .foregroundStyle(model.phase == .failed ? Color.red : (model.phase == .done ? Palette.green : Color.primary))
                if let p = model.progress { ProgressView(value: p) }

                if !model.steps.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(model.steps) { step in
                            HStack(spacing: 8) {
                                stepIcon(step)
                                Text(step.name).font(.caption).lineLimit(1)
                            }
                        }
                    }
                }
                if let url = model.runURL {
                    Link(destination: url) { smallLabel("Abrir la ejecucion en GitHub", "arrow.up.right.square") }
                }
                if let ipa = model.ipaURL {
                    ShareLink(item: ipa) { bigLabel("Enviar a SideStore / compartir", "square.and.arrow.up") }
                    Text("Tambien esta en Archivos > En mi iPhone > NxForge Studio. Cuando lo instales, borra el .ipa para liberar espacio.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            .padding(12)
            .background(Palette.field.opacity(0.5), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }

    @ViewBuilder
    private func stepIcon(_ step: GHStep) -> some View {
        switch (step.status, step.conclusion) {
        case ("completed", "success"): Image(systemName: "checkmark.circle.fill").foregroundStyle(Palette.green)
        case ("completed", "failure"): Image(systemName: "xmark.circle.fill").foregroundStyle(Color.red)
        case ("completed", _): Image(systemName: "minus.circle").foregroundStyle(.secondary)
        case ("in_progress", _): ProgressView().controlSize(.small)
        default: Image(systemName: "circle").foregroundStyle(.secondary)
        }
    }

    // MARK: Piezas

    private func field(_ title: String, text: Binding<String>) -> some View {
        TextField(title, text: text)
            .autocorrectionDisabled().textInputAutocapitalization(.never)
            .padding(10).background(Palette.field.opacity(0.7), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func secureField(_ title: String, text: Binding<String>) -> some View {
        SecureField(title, text: text)
            .autocorrectionDisabled().textInputAutocapitalization(.never)
            .padding(10).background(Palette.field.opacity(0.7), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func bigLabel(_ title: String, _ icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.headline).foregroundStyle(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 14)
            .background(theme.gradient.opacity(0.85), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func smallLabel(_ title: String, _ icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.subheadline.weight(.semibold)).foregroundStyle(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 10)
            .background(Palette.field.opacity(0.8), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
