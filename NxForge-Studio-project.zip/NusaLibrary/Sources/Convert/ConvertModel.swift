import SwiftUI
import UIKit

enum MemoryProfile: String, CaseIterable, Identifiable {
    case gb4 = "4gb", gb6 = "6gb", tex256 = "256", none = "none"
    var id: String { rawValue }
    var title: String {
        switch self {
        case .gb4: return "iPhone 12 / 13 / SE (4 GB)"
        case .gb6: return "iPhone 14 / 15 (6 GB)"
        case .tex256: return "Texturas 256 (si el juego se cierra al cargar)"
        case .none: return "iPhone 15 Pro o mas nuevo"
        }
    }
}

struct ConvertError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

/// Pide a GitHub que convierta el NSP en una Mac, espera, descarga el IPA cifrado y lo descifra.
@MainActor
final class ConvertModel: ObservableObject {
    enum Phase: Equatable { case idle, starting, building, downloading, decrypting, done, failed }

    @Published var phase: Phase = .idle
    @Published var steps: [GHStep] = []
    @Published var message = ""
    @Published var progress: Double?
    @Published var runURL: URL?
    @Published var ipaURL: URL?

    @Published var owner: String
    @Published var repo: String
    @Published var token: String
    @Published var password: String

    weak var log: LogStore?
    private var task: Task<Void, Never>?
    private var runID: Int?

    init() {
        let d = UserDefaults.standard
        owner = d.string(forKey: "convert.owner") ?? "Julianichuel"
        repo = d.string(forKey: "convert.repo") ?? "NXFORGE"
        token = Keychain.get("github-token")
        password = Keychain.get("artifact-password")
    }

    var isConfigured: Bool { !owner.isEmpty && !repo.isEmpty && !token.isEmpty && !password.isEmpty }
    var isBusy: Bool { [.starting, .building, .downloading, .decrypting].contains(phase) }

    func saveSettings() {
        let d = UserDefaults.standard
        d.set(owner.trimmingCharacters(in: .whitespaces), forKey: "convert.owner")
        d.set(repo.trimmingCharacters(in: .whitespaces), forKey: "convert.repo")
        Keychain.set(token.trimmingCharacters(in: .whitespacesAndNewlines), for: "github-token")
        Keychain.set(password, for: "artifact-password")
        token = token.trimmingCharacters(in: .whitespacesAndNewlines)
        log?.add("Ajustes de conversion guardados.", .ok)
    }

    private var client: GitHubClient {
        var c = GHConfig()
        c.owner = owner.trimmingCharacters(in: .whitespaces)
        c.repo = repo.trimmingCharacters(in: .whitespaces)
        c.token = token
        return GitHubClient(config: c)
    }

    // MARK: - Acciones

    func start(urlsText: String, profile: MemoryProfile) {
        guard isConfigured else { fail("Falta completar los ajustes (usuario, repo, token y contrasena)."); return }
        let urls = urlsText.split(whereSeparator: \.isNewline)
            .map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        guard !urls.isEmpty, urls.allSatisfy({ $0.lowercased().hasPrefix("http") }) else {
            fail("Pega uno o mas enlaces directos (que empiecen con http), uno por linea."); return
        }
        task = Task { [weak self] in await self?.runPipeline(urls: urls, profile: profile) }
    }

    /// Retoma la ultima ejecucion (por ejemplo si cerraste la app mientras compilaba).
    func resumeLatest() {
        guard isConfigured else { fail("Falta completar los ajustes."); return }
        task = Task { [weak self] in await self?.resume() }
    }

    func cancel() {
        task?.cancel()
        let id = runID
        let c = client
        if let id { Task { try? await c.cancel(id) } }
        phase = .idle
        message = "Cancelado."
        setIdleTimer(false)
    }

    // MARK: - Flujo

    private func runPipeline(urls: [String], profile: MemoryProfile) async {
        setIdleTimer(true); defer { setIdleTimer(false) }
        reset()
        do {
            phase = .starting
            message = "Enviando el pedido a GitHub..."
            let encrypted = try CryptoBox.encrypt(Data(urls.joined(separator: "\n").utf8), password: password)
            let c = client
            let started = Date()
            try await c.dispatch(inputs: ["game_url_enc": encrypted.base64EncodedString(),
                                          "memory": profile.rawValue, "runner": "xcode-27"])
            log?.add("Pedido enviado a GitHub (\(profile.rawValue)).", .info)

            var found: GHRun?
            for _ in 0..<20 {
                try Task.checkCancellation()
                try await Task.sleep(nanoseconds: 3_000_000_000)
                found = try await c.latestRun(after: started.addingTimeInterval(-60))
                if found != nil { break }
            }
            guard let run = found else { throw ConvertError(message: "GitHub no mostro la ejecucion. Abre la pestana Actions del repo para ver si arranco.") }
            try await follow(c, run: run)
        } catch is CancellationError {
            // cancelado por el usuario
        } catch {
            fail(error.localizedDescription)
        }
    }

    private func resume() async {
        setIdleTimer(true); defer { setIdleTimer(false) }
        reset()
        do {
            phase = .starting
            message = "Buscando la ultima ejecucion..."
            let c = client
            guard let run = try await c.latestRun(after: .distantPast) else {
                throw ConvertError(message: "No hay ejecuciones lanzadas desde la app en ese repositorio.")
            }
            try await follow(c, run: run)
        } catch is CancellationError {
        } catch {
            fail(error.localizedDescription)
        }
    }

    private func follow(_ c: GitHubClient, run first: GHRun) async throws {
        runID = first.id
        runURL = first.htmlUrl
        phase = .building
        while true {
            try Task.checkCancellation()
            let r = try await c.run(first.id)
            if let job = try? await c.jobs(first.id).first {
                steps = job.steps ?? []
                if let current = steps.first(where: { $0.status == "in_progress" }) {
                    message = "En GitHub: \(current.name)"
                } else {
                    message = r.status == "queued" ? "En cola en GitHub (esperando una Mac)..." : "En GitHub: preparando..."
                }
            }
            if r.status == "completed" {
                guard r.conclusion == "success" else {
                    let failed = steps.first(where: { $0.conclusion == "failure" })?.name
                    throw ConvertError(message: failed.map { "Fallo el paso: \($0). Abre la ejecucion en GitHub para ver el error y mandamelo." }
                                       ?? "La ejecucion termino con: \(r.conclusion ?? "desconocido").")
                }
                break
            }
            try await Task.sleep(nanoseconds: 15_000_000_000)
        }
        log?.add("GitHub termino la conversion. Descargando...", .ok)
        try await fetchResult(c, runID: first.id)
    }

    private func fetchResult(_ c: GitHubClient, runID: Int) async throws {
        let list = try await c.artifacts(runID).filter { !$0.expired }
        guard let artifact = list.first(where: { $0.name == "game-ipa-enc" }) else {
            throw ConvertError(message: "La ejecucion no dejo ningun resultado (o ya vencio, dura 1 dia).")
        }
        let needed = artifact.sizeInBytes * 2 + 500_000_000
        let free = freeBytes()
        let fmt = { (n: Int64) in ByteCountFormatter.string(fromByteCount: n, countStyle: .file) }
        guard free > needed else {
            throw ConvertError(message: "Falta espacio en el iPhone: hacen falta unos \(fmt(needed)) libres y hay \(fmt(free)).")
        }

        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let zipURL = docs.appendingPathComponent("descarga.zip")
        let ipaURL = docs.appendingPathComponent("Juego-\(Int(Date().timeIntervalSince1970)).ipa")
        let total = Double(max(artifact.sizeInBytes, 1))

        phase = .downloading
        message = "Descargando \(fmt(artifact.sizeInBytes)). Deja la app abierta."
        progress = 0
        let downloader = ArtifactDownloader(destination: zipURL) { [weak self] written in
            Task { @MainActor in self?.progress = min(Double(written) / total, 1) }
        }
        _ = try await downloader.download(c.artifactRequest(artifact.id))

        phase = .decrypting
        message = "Descifrando el IPA..."
        progress = 0
        let zip = try ZipReader(url: zipURL)
        let entries = try zip.entries()
        guard entries.count == 1, let entry = entries.first, entry.method == 0 else {
            throw ConvertError(message: "El zip descargado no tiene el formato esperado.")
        }
        let range = try zip.dataRange(of: entry)
        let pw = password
        try await Task.detached(priority: .userInitiated) { [weak self] in
            try CryptoBox.decryptRange(of: zipURL, offset: range.offset, length: range.length, to: ipaURL, password: pw) { p in
                Task { @MainActor in self?.progress = p }
            }
        }.value
        try? FileManager.default.removeItem(at: zipURL)

        self.ipaURL = ipaURL
        progress = nil
        phase = .done
        message = "Listo: \(ipaURL.lastPathComponent) (\(fmt(range.length)))"
        log?.add("IPA listo: \(ipaURL.lastPathComponent)", .ok)
    }

    // MARK: - Utilidades

    private func reset() {
        steps = []; progress = nil; runURL = nil; ipaURL = nil; runID = nil; message = ""
    }

    private func fail(_ text: String) {
        phase = .failed
        progress = nil
        message = text
        log?.add(text, .error)
    }

    private func setIdleTimer(_ on: Bool) { UIApplication.shared.isIdleTimerDisabled = on }

    private func freeBytes() -> Int64 {
        let url = URL(fileURLWithPath: NSHomeDirectory())
        let values = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return values?.volumeAvailableCapacityForImportantUsage ?? 0
    }
}
