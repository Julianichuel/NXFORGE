import Foundation
import CommonCrypto

enum CryptoBoxError: LocalizedError {
    case badFormat, wrongPassword, failed(String)
    var errorDescription: String? {
        switch self {
        case .badFormat: return "El archivo cifrado no tiene el formato esperado."
        case .wrongPassword: return "La contrasena no coincide con la del secreto ARTIFACT_PASSWORD."
        case .failed(let m): return m
        }
    }
}

/// Compatible con `openssl enc -aes-256-cbc -pbkdf2 -iter 10000 -salt` (formato "Salted__").
enum CryptoBox {
    static let iterations: UInt32 = 10_000
    private static let magic: [UInt8] = Array("Salted__".utf8)

    private static func deriveKeyIV(password: String, salt: [UInt8]) throws -> (key: [UInt8], iv: [UInt8]) {
        var derived = [UInt8](repeating: 0, count: 48)
        let status = CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), password, password.utf8.count,
                                          salt, salt.count,
                                          CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), iterations,
                                          &derived, derived.count)
        guard status == Int32(kCCSuccess) else { throw CryptoBoxError.failed("No se pudo derivar la clave (\(status)).") }
        return (Array(derived[0..<32]), Array(derived[32..<48]))
    }

    /// Cifra un texto corto (los enlaces del juego) para mandarlo a GitHub.
    static func encrypt(_ plain: Data, password: String) throws -> Data {
        var salt = [UInt8](repeating: 0, count: 8)
        guard SecRandomCopyBytes(kSecRandomDefault, salt.count, &salt) == errSecSuccess else {
            throw CryptoBoxError.failed("No hay generador aleatorio disponible.")
        }
        let (key, iv) = try deriveKeyIV(password: password, salt: salt)
        let input = [UInt8](plain)
        var out = [UInt8](repeating: 0, count: input.count + kCCBlockSizeAES128)
        var moved = 0
        let status = CCCrypt(CCOperation(kCCEncrypt), CCAlgorithm(kCCAlgorithmAES), CCOptions(kCCOptionPKCS7Padding),
                             key, key.count, iv, input, input.count, &out, out.count, &moved)
        guard status == Int32(kCCSuccess) else { throw CryptoBoxError.failed("No se pudo cifrar (\(status)).") }
        var result = Data(magic)
        result.append(contentsOf: salt)
        result.append(contentsOf: out[0..<moved])
        return result
    }

    /// Descifra por partes (4 MB) un rango de un archivo, para IPA de varios GB sin llenar la memoria.
    static func decryptRange(of source: URL, offset: UInt64, length: UInt64, to dest: URL, password: String,
                             progress: @escaping @Sendable (Double) -> Void) throws {
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }
        try input.seek(toOffset: offset)
        guard length > 16, let head = try input.read(upToCount: 16), head.count == 16,
              Array(head.prefix(8)) == magic else { throw CryptoBoxError.badFormat }
        let salt = Array(head.suffix(8))
        let (key, iv) = try deriveKeyIV(password: password, salt: salt)

        var cryptor: CCCryptorRef?
        let created = CCCryptorCreate(CCOperation(kCCDecrypt), CCAlgorithm(kCCAlgorithmAES),
                                      CCOptions(kCCOptionPKCS7Padding), key, key.count, iv, &cryptor)
        guard created == Int32(kCCSuccess), let c = cryptor else { throw CryptoBoxError.failed("No se pudo iniciar el descifrado.") }
        defer { CCCryptorRelease(c) }

        let fm = FileManager.default
        try? fm.removeItem(at: dest)
        guard fm.createFile(atPath: dest.path, contents: nil) else { throw CryptoBoxError.failed("No se pudo crear el archivo de salida.") }
        let output = try FileHandle(forWritingTo: dest)
        defer { try? output.close() }

        var remaining = length - 16
        let total = Double(remaining)
        let chunkSize: UInt64 = 4 * 1024 * 1024
        while remaining > 0 {
            try autoreleasepool {
                let n = Int(min(chunkSize, remaining))
                guard let data = try input.read(upToCount: n), !data.isEmpty else { throw CryptoBoxError.badFormat }
                var out = [UInt8](repeating: 0, count: data.count + kCCBlockSizeAES128)
                var moved = 0
                let status = data.withUnsafeBytes { raw in
                    CCCryptorUpdate(c, raw.baseAddress, data.count, &out, out.count, &moved)
                }
                guard status == Int32(kCCSuccess) else { throw CryptoBoxError.failed("Fallo al descifrar (\(status)).") }
                try output.write(contentsOf: Data(out[0..<moved]))
                remaining -= UInt64(data.count)
            }
            progress(1 - Double(remaining) / total)
        }
        var tail = [UInt8](repeating: 0, count: kCCBlockSizeAES128)
        var tailMoved = 0
        let fin = CCCryptorFinal(c, &tail, tail.count, &tailMoved)
        guard fin == Int32(kCCSuccess) else { try? fm.removeItem(at: dest); throw CryptoBoxError.wrongPassword }
        if tailMoved > 0 { try output.write(contentsOf: Data(tail[0..<tailMoved])) }
        try output.synchronize()

        // Un IPA es un zip: si no empieza con "PK", la contrasena era otra.
        let check = try FileHandle(forReadingFrom: dest)
        defer { try? check.close() }
        guard let first = try check.read(upToCount: 2), first == Data([0x50, 0x4B]) else {
            try? fm.removeItem(at: dest)
            throw CryptoBoxError.wrongPassword
        }
    }
}
