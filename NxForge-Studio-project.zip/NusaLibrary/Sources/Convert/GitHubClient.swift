import Foundation

struct GHConfig {
    var owner = "Julianichuel"
    var repo = "NXFORGE"
    var workflow = "build-game-ipa.yml"
    var ref = "main"
    var token = ""
}

enum GHError: LocalizedError {
    case http(Int, String)
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let m): return m
        case .http(let code, let text):
            let hint: String
            switch code {
            case 401: hint = "El token no es valido o vencio."
            case 403: hint = "El token no tiene permiso (necesita Actions: lectura y escritura) o se agoto el limite."
            case 404: hint = "No se encontro el repositorio o el workflow. Revisa el usuario, el repo y que build-game-ipa.yml este en .github/workflows."
            case 422: hint = "GitHub rechazo el pedido. Suele ser que el workflow no tenga workflow_dispatch o que falte la rama."
            default: hint = "Error de GitHub."
            }
            return "GitHub respondio \(code): \(hint) \(text)"
        }
    }
}

struct GHRun: Decodable {
    let id: Int
    let status: String
    let conclusion: String?
    let htmlUrl: URL
    let createdAt: Date
}
struct GHStep: Decodable, Identifiable {
    let name: String
    let status: String
    let conclusion: String?
    let number: Int
    var id: Int { number }
}
struct GHJob: Decodable {
    let name: String
    let status: String
    let conclusion: String?
    let steps: [GHStep]?
}
struct GHArtifact: Decodable {
    let id: Int
    let name: String
    let sizeInBytes: Int64
    let expired: Bool
}

struct GitHubClient {
    let config: GHConfig

    private var base: String { "https://api.github.com/repos/\(config.owner)/\(config.repo)" }

    private func makeRequest(_ path: String, method: String = "GET", body: Data? = nil) -> URLRequest {
        var r = URLRequest(url: URL(string: base + path)!)
        r.httpMethod = method
        r.httpBody = body
        r.setValue("Bearer \(config.token)", forHTTPHeaderField: "Authorization")
        r.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        r.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        r.setValue("NxForgeStudio", forHTTPHeaderField: "User-Agent")
        if body != nil { r.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        return r
    }

    @discardableResult
    private func send(_ request: URLRequest) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw GHError.message("Respuesta invalida de GitHub.") }
        guard (200..<300).contains(http.statusCode) else {
            let text = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["message"] as? String ?? ""
            throw GHError.http(http.statusCode, text)
        }
        return data
    }

    private var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        d.dateDecodingStrategy = .iso8601
        return d
    }

    func dispatch(inputs: [String: String]) async throws {
        let body = try JSONSerialization.data(withJSONObject: ["ref": config.ref, "inputs": inputs])
        try await send(makeRequest("/actions/workflows/\(config.workflow)/dispatches", method: "POST", body: body))
    }

    /// Ejecucion mas reciente lanzada a mano, creada despues de `after`.
    func latestRun(after: Date) async throws -> GHRun? {
        struct List: Decodable { let workflowRuns: [GHRun] }
        let data = try await send(makeRequest("/actions/workflows/\(config.workflow)/runs?event=workflow_dispatch&per_page=5"))
        let list = try decoder.decode(List.self, from: data)
        return list.workflowRuns.filter { $0.createdAt >= after }.max { $0.createdAt < $1.createdAt }
    }

    func run(_ id: Int) async throws -> GHRun {
        try decoder.decode(GHRun.self, from: try await send(makeRequest("/actions/runs/\(id)")))
    }

    func jobs(_ runID: Int) async throws -> [GHJob] {
        struct List: Decodable { let jobs: [GHJob] }
        return try decoder.decode(List.self, from: try await send(makeRequest("/actions/runs/\(runID)/jobs"))).jobs
    }

    func artifacts(_ runID: Int) async throws -> [GHArtifact] {
        struct List: Decodable { let artifacts: [GHArtifact] }
        return try decoder.decode(List.self, from: try await send(makeRequest("/actions/runs/\(runID)/artifacts"))).artifacts
    }

    func cancel(_ runID: Int) async throws {
        try await send(makeRequest("/actions/runs/\(runID)/cancel", method: "POST"))
    }

    func artifactRequest(_ id: Int) -> URLRequest { makeRequest("/actions/artifacts/\(id)/zip") }
}

/// Descarga un archivo grande a disco con progreso. Al seguir la redireccion a otro servidor
/// quita la cabecera Authorization (el enlace de descarga ya viene firmado).
final class ArtifactDownloader: NSObject, URLSessionDownloadDelegate {
    private let destination: URL
    private var continuation: CheckedContinuation<URL, Error>?
    private var session: URLSession?
    private let onProgress: @Sendable (Int64) -> Void

    init(destination: URL, onProgress: @escaping @Sendable (Int64) -> Void) {
        self.destination = destination
        self.onProgress = onProgress
    }

    func download(_ request: URLRequest) async throws -> URL {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<URL, Error>) in
            continuation = c
            let s = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
            session = s
            s.downloadTask(with: request).resume()
        }
    }

    private func finish(_ result: Result<URL, Error>) {
        guard let c = continuation else { return }
        continuation = nil
        session?.finishTasksAndInvalidate()
        c.resume(with: result)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        var next = request
        next.setValue(nil, forHTTPHeaderField: "Authorization")
        completionHandler(next)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        onProgress(totalBytesWritten)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        if let http = downloadTask.response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            finish(.failure(GHError.http(http.statusCode, "No se pudo descargar el artefacto (puede haber vencido).")))
            return
        }
        do {
            try? FileManager.default.removeItem(at: destination)
            try FileManager.default.moveItem(at: location, to: destination)
            finish(.success(destination))
        } catch {
            finish(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error { finish(.failure(error)) }
    }
}
