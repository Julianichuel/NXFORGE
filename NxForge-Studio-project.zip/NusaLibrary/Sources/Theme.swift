import SwiftUI

struct AppTheme: Identifiable, Hashable {
    let id: String
    let name: String
    let a: Color
    let b: Color
    var gradient: LinearGradient { LinearGradient(colors: [a, b], startPoint: .leading, endPoint: .trailing) }

    static let swirl = AppTheme(id: "swirl", name: "Swirl", a: Color(red: 0.12, green: 0.68, blue: 1.0), b: Color(red: 0.95, green: 0.27, blue: 0.38))
    static let joy = AppTheme(id: "joy", name: "Joy-Blue", a: Color(red: 0.12, green: 0.68, blue: 1.0), b: Color(red: 0.33, green: 0.38, blue: 0.98))
    static let crimson = AppTheme(id: "crimson", name: "Crimson", a: Color(red: 0.95, green: 0.27, blue: 0.38), b: Color(red: 1.0, green: 0.55, blue: 0.15))
    static let amber = AppTheme(id: "amber", name: "Amber", a: Color(red: 1.0, green: 0.78, blue: 0.20), b: Color(red: 1.0, green: 0.45, blue: 0.15))
    static let all = [swirl, joy, crimson, amber]
    static func byID(_ id: String) -> AppTheme { all.first { $0.id == id } ?? swirl }
}

enum Palette {
    static let bgTop = Color(red: 0.03, green: 0.09, blue: 0.13)
    static let bgBottom = Color(red: 0.14, green: 0.04, blue: 0.08)
    static let card = Color(red: 0.08, green: 0.10, blue: 0.16)
    static let field = Color(red: 0.11, green: 0.14, blue: 0.22)
    static let blue = Color(red: 0.12, green: 0.68, blue: 1.0)
    static let red = Color(red: 0.95, green: 0.27, blue: 0.38)
    static let green = Color(red: 0.25, green: 0.85, blue: 0.55)
    static let amber = Color(red: 1.0, green: 0.78, blue: 0.20)
}

/// Tarjeta con borde fino y una linea de acento en degradado arriba.
struct CardStyle: ViewModifier {
    let theme: AppTheme
    func body(content: Content) -> some View {
        content
            .padding(16)
            .background(Palette.card.opacity(0.94), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(.white.opacity(0.07)))
            .overlay(alignment: .top) {
                theme.gradient.frame(height: 3).clipShape(Capsule()).padding(.horizontal, 36)
            }
    }
}

extension View {
    func card(_ theme: AppTheme) -> some View { modifier(CardStyle(theme: theme)) }
}

/// Fila de estado a todo el ancho: icono + texto, con color de fondo suave.
struct StatusPill: View {
    let icon: String
    let title: String
    let detail: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.title3.weight(.bold))
            Text(title).font(.headline)
            Text("\u{2022}").opacity(0.6)
            Text(detail).font(.headline).lineLimit(1).minimumScaleFactor(0.7)
            Spacer(minLength: 0)
        }
        .foregroundStyle(color)
        .padding(.horizontal, 16).padding(.vertical, 14)
        .background(color.opacity(0.17), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

struct ThemeDots: View {
    @Binding var themeID: String

    var body: some View {
        HStack(spacing: 10) {
            ForEach(AppTheme.all) { t in
                Button { themeID = t.id } label: {
                    Circle()
                        .fill(LinearGradient(colors: [t.a, t.b], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 26, height: 26)
                        .overlay(Circle().stroke(.white, lineWidth: themeID == t.id ? 2.5 : 0).padding(-4))
                }
                .buttonStyle(.plain)
                .accessibilityLabel(t.name)
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(Palette.field.opacity(0.8), in: Capsule())
    }
}

struct PillButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.7 : 1)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}
