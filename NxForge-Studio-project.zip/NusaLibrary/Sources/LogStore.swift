import SwiftUI

@MainActor
final class LogStore: ObservableObject {
    enum Level { case info, ok, error }
    struct Line: Identifiable {
        let id = UUID()
        let level: Level
        let text: String
        let date = Date()
    }

    @Published private(set) var lines: [Line] = []

    func add(_ text: String, _ level: Level = .info) {
        lines.append(Line(level: level, text: text))
        if lines.count > 500 { lines.removeFirst(lines.count - 500) }
    }

    func clear() { lines.removeAll() }

    var asText: String {
        lines.map { "[\($0.level)] \($0.text)" }.joined(separator: "\n")
    }
}
