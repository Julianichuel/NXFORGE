import SwiftUI
import Foundation

/// Importa y valida un archivo prod.keys (formato "nombre = hex").
/// Los valores de las keys nunca se muestran ni se escriben en el log.
@MainActor
final class KeyStore: ObservableObject {
    enum Status: Equatable {
        case missing
        case incomplete(found: Int)
        case ready(found: Int)
    }

    @Published private(set) var status: Status = .missing
    @Published private(set) var keyCount = 0
    @Published private(set) var foundNames: Set<String> = []

    struct ChecklistItem { let name: String; let present: Bool }
    var requiredChecklist: [ChecklistItem] {
        let base = ["header_key", "aes_kek_generation_source", "key_area_key_application_source", "titlekek_source"]
        var items = base.map { ChecklistItem(name: $0, present: foundNames.contains($0)) }
        items.append(ChecklistItem(name: "master_key_XX (al menos una)", present: foundNames.contains { $0.hasPrefix("master_key_") }))
        return items
    }
    private var log: LogStore?

    private var storeURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("keys", isDirectory: true).appendingPathComponent("prod.keys")
    }

    func attach(log: LogStore) {
        guard self.log == nil else { return }
        self.log = log
        if let text = try? String(contentsOf: storeURL, encoding: .utf8) {
            apply(parse(text))
            log.add("prod.keys cargado desde el almacenamiento de la app", .ok)
        }
    }

    /// Resultado del analisis de un prod.keys.
    struct Parsed {
        var names: Set<String> = []
        var invalidLines = 0
    }

    func parse(_ text: String) -> Parsed {
        var result = Parsed()
        for raw in text.split(whereSeparator: \.isNewline) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix(";") || line.hasPrefix("#") { continue }
            let parts = line.split(separator: "=", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            guard parts.count == 2, !parts[0].isEmpty else { result.invalidLines += 1; continue }
            let value = parts[1]
            let isHex = !value.isEmpty && value.count % 2 == 0 && value.allSatisfy(\.isHexDigit)
            if isHex { result.names.insert(parts[0].lowercased()) } else { result.invalidLines += 1 }
        }
        return result
    }

    private func apply(_ p: Parsed) {
        keyCount = p.names.count
        foundNames = p.names
        // Nombres minimos que suelen venir en un prod.keys completo.
        let required = ["header_key", "aes_kek_generation_source", "key_area_key_application_source", "titlekek_source"]
        let hasRequired = required.allSatisfy { p.names.contains($0) }
        let hasMaster = p.names.contains { $0.hasPrefix("master_key_") }
        if p.names.isEmpty {
            status = .missing
        } else if hasRequired && hasMaster {
            status = .ready(found: p.names.count)
        } else {
            status = .incomplete(found: p.names.count)
        }
    }

    func importKeys(from url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let text = try String(contentsOf: url, encoding: .utf8)
            let parsed = parse(text)
            guard !parsed.names.isEmpty else {
                log?.add("El archivo no parece un prod.keys valido (0 keys leidas).", .error)
                return
            }
            let dir = storeURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try text.write(to: storeURL, atomically: true, encoding: .utf8)
            var values = URLResourceValues(); values.isExcludedFromBackup = true
            var target = storeURL; try? target.setResourceValues(values)
            apply(parsed)
            if parsed.invalidLines > 0 {
                log?.add("\(parsed.invalidLines) lineas ignoradas por formato invalido.", .info)
            }
            switch status {
            case .ready(let n): log?.add("prod.keys importado: \(n) keys.", .ok)
            case .incomplete(let n): log?.add("prod.keys importado pero incompleto (\(n) keys). Faltan keys base o master_key.", .error)
            case .missing: break
            }
        } catch {
            log?.add("No se pudo leer el archivo: \(error.localizedDescription)", .error)
        }
    }

    /// prod.keys en base64, solo para copiarlo al portapapeles y pegarlo en un secreto de GitHub.
    func exportBase64() -> String? {
        guard let data = try? Data(contentsOf: storeURL) else { return nil }
        return data.base64EncodedString()
    }

    func remove() {
        try? FileManager.default.removeItem(at: storeURL)
        status = .missing
        keyCount = 0
        foundNames = []
        log?.add("prod.keys eliminado.", .info)
    }
}
