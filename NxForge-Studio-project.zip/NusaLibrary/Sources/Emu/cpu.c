#include "cpu.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool cpu_init(Cpu *cpu, size_t mem_size, uint64_t base) {
    memset(cpu, 0, sizeof *cpu);
    cpu->mem = calloc(1, mem_size);
    if (!cpu->mem) return false;
    cpu->mem_size = mem_size;
    cpu->base = base;
    cpu->pc = base;
    cpu->sp = (base + mem_size) & ~15ull;
    return true;
}

void cpu_free(Cpu *cpu) { free(cpu->mem); cpu->mem = NULL; }

bool cpu_load(Cpu *cpu, const uint8_t *code, size_t len, uint64_t offset) {
    if (offset > cpu->mem_size || len > cpu->mem_size - offset) return false;
    memcpy(cpu->mem + offset, code, len);
    return true;
}

static void fail(Cpu *c, const char *fmt, uint64_t a, uint32_t insn) {
    snprintf(c->error, sizeof c->error, fmt, (unsigned long long)a, insn);
    c->halted = true;
}

/* ---- memoria ---- */
static bool mem_ok(Cpu *c, uint64_t addr, size_t n) {
    return addr >= c->base && addr - c->base <= c->mem_size && n <= c->mem_size - (addr - c->base);
}
static bool mem_read(Cpu *c, uint64_t addr, int size, uint64_t *out) {
    if (!mem_ok(c, addr, (size_t)size)) { fail(c, "lectura fuera de rango en 0x%llx (insn %08x)", addr, 0); return false; }
    uint64_t v = 0;
    memcpy(&v, c->mem + (addr - c->base), (size_t)size);  /* host little-endian */
    *out = v;
    return true;
}
static bool mem_write(Cpu *c, uint64_t addr, int size, uint64_t v) {
    if (!mem_ok(c, addr, (size_t)size)) { fail(c, "escritura fuera de rango en 0x%llx (insn %08x)", addr, 0); return false; }
    memcpy(c->mem + (addr - c->base), &v, (size_t)size);
    return true;
}

/* ---- registros ---- */
static uint64_t rd_zr(Cpu *c, unsigned r) { return r == 31 ? 0 : c->x[r]; }
static uint64_t rd_sp(Cpu *c, unsigned r) { return r == 31 ? c->sp : c->x[r]; }
static void wr_zr(Cpu *c, unsigned r, uint64_t v) { if (r != 31) c->x[r] = v; }
static void wr_sp(Cpu *c, unsigned r, uint64_t v) { if (r == 31) c->sp = v; else c->x[r] = v; }
static uint64_t trunc_sf(uint64_t v, bool sf) { return sf ? v : (v & 0xFFFFFFFFull); }
static int64_t sext(uint64_t v, unsigned bits) {
    uint64_t m = 1ull << (bits - 1);
    v &= (bits == 64) ? ~0ull : ((1ull << bits) - 1);
    return (int64_t)((v ^ m) - m);
}

static uint64_t add_with_carry(Cpu *c, uint64_t a, uint64_t b, unsigned carry, bool sf, bool setf) {
    unsigned bits = sf ? 64 : 32;
    uint64_t mask = sf ? ~0ull : 0xFFFFFFFFull;
    a &= mask; b &= mask;
    uint64_t r = (a + b + carry) & mask;
    if (setf) {
        c->n = (r >> (bits - 1)) & 1;
        c->z = r == 0;
        c->c = sf ? ((r < a) || (carry && r == a)) : ((a + b + carry) > mask);
        uint64_t sa = (a >> (bits - 1)) & 1, sb = (b >> (bits - 1)) & 1, sr = (r >> (bits - 1)) & 1;
        c->v = (sa == sb) && (sr != sa);
    }
    return r;
}

static bool cond_holds(Cpu *c, unsigned cond) {
    bool r;
    switch (cond >> 1) {
        case 0: r = c->z; break;
        case 1: r = c->c; break;
        case 2: r = c->n; break;
        case 3: r = c->v; break;
        case 4: r = c->c && !c->z; break;
        case 5: r = c->n == c->v; break;
        case 6: r = (c->n == c->v) && !c->z; break;
        default: r = true; break;
    }
    if ((cond & 1) && cond != 15) r = !r;
    return r;
}

static uint64_t shift_val(uint64_t v, unsigned type, unsigned amt, bool sf) {
    unsigned bits = sf ? 64 : 32;
    v = trunc_sf(v, sf);
    amt %= bits;
    switch (type) {
        case 0: return trunc_sf(v << amt, sf);
        case 1: return v >> amt;
        case 2: return trunc_sf((uint64_t)(sext(v, bits) >> amt), sf);
        default: return amt ? trunc_sf((v >> amt) | (v << (bits - amt)), sf) : v;
    }
}

/* Carga/almacena un entero. opc: 0=STR, 1=LDR (zero-ext), 2=LDRS a X, 3=LDRS a W. */
static bool ldst(Cpu *c, unsigned size, unsigned opc, unsigned rt, uint64_t addr, uint64_t pc, uint32_t insn) {
    if (opc == 0) return mem_write(c, addr, 1 << size, rd_zr(c, rt));
    if (opc == 1) { uint64_t v; if (!mem_read(c, addr, 1 << size, &v)) return false; wr_zr(c, rt, v); return true; }
    if (size == 3) { if (opc == 2) return true; /* PRFM: sin efecto */ fail(c, "LDR/STR variante no soportada en 0x%llx (insn %08x)", pc, insn); return false; }
    if (opc == 3 && size == 2) { fail(c, "LDRS invalido en 0x%llx (insn %08x)", pc, insn); return false; }
    uint64_t v; if (!mem_read(c, addr, 1 << size, &v)) return false;
    uint64_t r = (uint64_t)sext(v, 8u << size);
    wr_zr(c, rt, opc == 3 ? (r & 0xFFFFFFFFull) : r);
    return true;
}

static uint64_t ext_val(uint64_t v, unsigned option, unsigned shift) {
    switch (option) {
        case 0: v &= 0xFF; break;
        case 1: v &= 0xFFFF; break;
        case 2: v &= 0xFFFFFFFFull; break;
        case 3: break;
        case 4: v = (uint64_t)sext(v, 8); break;
        case 5: v = (uint64_t)sext(v, 16); break;
        case 6: v = (uint64_t)sext(v, 32); break;
        default: break;
    }
    return v << shift;
}

#define SYSREG(o0, op1, crn, crm, op2) (((o0) << 14) | ((op1) << 11) | ((crn) << 7) | ((crm) << 3) | (op2))

/* ---- SVC de Horizon (subconjunto) ---- */
#define RES_OK 0u
#define RES_TIMEOUT 0xEA01u
#define RES_INVALID 0xE401u
#define RES_NOTFOUND 0xF601u
#define RES_UNSUPPORTED 0xF001u

static void do_svc_horizon(Cpu *c, unsigned imm) {
    c->svc_count++;
    switch (imm) {
        case 0x01: { /* SetHeapSize(x1=size) -> w0=res, x1=addr */
            uint64_t want = c->x[1];
            if (want > c->heap_max) { c->x[0] = 0xD001u; c->x[1] = 0; break; } /* OutOfResource */
            c->heap_size = want; c->x[0] = RES_OK; c->x[1] = c->heap_base; break;
        }
        case 0x03: case 0x04: case 0x05: c->x[0] = RES_OK; break;  /* SetMemoryAttribute/MapMemory/UnmapMemory */
        case 0x06: { /* QueryMemory(x0=meminfo*, x2=addr) -> w0, x1=pageinfo */
            uint64_t out = c->x[0], addr = c->x[2];
            uint8_t info[0x28] = {0};
            uint64_t base = c->base, size = c->mem_size;
            if (addr < c->base || addr >= c->base + c->mem_size) { base = 0; size = c->base; if (addr >= c->base) { base = c->base + c->mem_size; size = 0x10000000ull; } }
            uint32_t type = (base == c->base) ? 3u /* CodeStatic */ : 0u /* Unmapped */;
            uint32_t perm = (type == 0) ? 0u : 3u;
            memcpy(info, &base, 8); memcpy(info + 8, &size, 8); memcpy(info + 16, &type, 4); memcpy(info + 24, &perm, 4);
            for (size_t k = 0; k < sizeof info; k++) if (!mem_write(c, out + k, 1, info[k])) return;
            c->x[0] = RES_OK; c->x[1] = 0; break;
        }
        case 0x07: c->exit_code = 0; c->halted = true; break;               /* ExitProcess */
        case 0x08: c->x[0] = RES_UNSUPPORTED; break;                        /* CreateThread */
        case 0x0B: c->x[0] = 0; break;                                      /* SleepThread */
        case 0x0C: c->x[0] = RES_OK; c->x[1] = 44; break;                   /* GetThreadPriority */
        case 0x0D: c->x[0] = RES_OK; break;                                 /* SetThreadPriority */
        case 0x0F: case 0x10: c->x[0] = RES_OK; c->x[1] = 0; break;         /* Get/SetThreadCoreMask */
        case 0x11: case 0x12: case 0x13: c->x[0] = RES_OK; break;           /* Signal/Clear events etc. */
        case 0x16: case 0x17: c->x[0] = RES_OK; break;
        case 0x18: c->x[0] = RES_TIMEOUT; break;                            /* WaitSynchronization */
        case 0x19: c->x[0] = RES_OK; break;                                 /* CloseHandle */
        case 0x1F: c->x[0] = RES_NOTFOUND; break;                           /* ConnectToNamedPort: sin servicios */
        case 0x21: c->x[0] = RES_UNSUPPORTED; break;                        /* SendSyncRequest */
        case 0x25: c->x[0] = RES_OK; c->x[1] = 1; break;                    /* GetThreadId */
        case 0x26: snprintf(c->error, sizeof c->error, "svcBreak (codigo %llx)", (unsigned long long)c->x[0]); c->halted = true; break;
        case 0x27: { /* OutputDebugString(x0=ptr, x1=len) */
            uint64_t addr = c->x[0], len = c->x[1];
            if (!mem_ok(c, addr, len)) { c->x[0] = RES_INVALID; break; }
            if (c->write_fn) c->write_fn(c->write_user, 1, c->mem + (addr - c->base), len);
            c->x[0] = RES_OK; break;
        }
        case 0x29: { /* GetInfo(x1=id, x2=handle, x3=sub) -> w0, x1 */
            uint64_t id = c->x[1], v = 0; uint32_t res = RES_OK;
            switch (id) {
                case 0: v = 1; break;                                 /* CoreMask */
                case 1: v = ~0ull; break;                             /* PriorityMask */
                case 2: v = c->base + c->mem_size; break;             /* AliasRegionAddress */
                case 3: v = 0x1000000; break;                         /* AliasRegionSize */
                case 4: v = c->heap_base; break;                      /* HeapRegionAddress */
                case 5: v = c->heap_max; break;                       /* HeapRegionSize */
                case 6: v = c->mem_size; break;                       /* TotalMemorySize */
                case 7: v = (c->heap_base - c->base) + c->heap_size; break; /* UsedMemorySize */
                case 12: v = c->base; break;                          /* AslrRegionAddress */
                case 13: v = c->mem_size; break;                      /* AslrRegionSize */
                case 14: v = c->stack_base; break;                    /* StackRegionAddress */
                case 15: v = c->stack_size; break;                    /* StackRegionSize */
                case 16: case 17: v = 0; break;                       /* SystemResource */
                case 18: v = 0x0100000000001000ull; break;            /* ProgramId (falso) */
                default: res = RES_INVALID; break;
            }
            c->x[0] = res; c->x[1] = v; break;
        }
        default:
            snprintf(c->error, sizeof c->error, "SVC 0x%x de Horizon no implementada", imm);
            c->halted = true; break;
    }
}

static void do_syscall(Cpu *c) {
    switch (c->x[8]) {
        case 200: c->frame_ready = true; break;   /* presentar cuadro */
        case 93: c->exit_code = (int64_t)c->x[0]; c->halted = true; break;
        case 64: {
            uint64_t addr = c->x[1], len = c->x[2];
            if (!mem_ok(c, addr, len)) { fail(c, "write con buffer invalido 0x%llx (insn %08x)", addr, 0); return; }
            if (c->write_fn) c->write_fn(c->write_user, (int)c->x[0], c->mem + (addr - c->base), len);
            c->x[0] = len;
            break;
        }
        default: c->x[0] = (uint64_t)-38; break;  /* ENOSYS */
    }
}

bool cpu_step(Cpu *c) {
    if (c->halted) return false;
    uint64_t insn64;
    if (!mem_read(c, c->pc, 4, &insn64)) return false;
    uint32_t i = (uint32_t)insn64;
    uint64_t pc = c->pc;
    uint64_t next = pc + 4;
    bool sf = (i >> 31) & 1;
    unsigned rd = i & 31, rn = (i >> 5) & 31, rm = (i >> 16) & 31;
    c->steps++;

    if (i == 0xD503201Fu) { /* NOP */
    }
    /* HINT (yield, wfe...) y barreras: CLREX / DSB / DMB / ISB */
    else if ((i & 0xFFFFF01Fu) == 0xD503201Fu || (i & 0xFFFFF01Fu) == 0xD503301Fu) { }
    /* MRS / MSR de registros de sistema */
    else if ((i & 0xFFF00000u) == 0xD5300000u || (i & 0xFFF00000u) == 0xD5100000u) {
        bool read = (i & 0x00200000u) != 0;
        unsigned key = (i >> 5) & 0x7FFF;
        uint64_t *slot = NULL, val = 0; bool known = true;
        if (key == SYSREG(1, 3, 13, 0, 2)) slot = &c->tpidr;                       /* TPIDR_EL0 */
        else if (key == SYSREG(1, 3, 13, 0, 3)) { slot = &c->tpidrro; }             /* TPIDRRO_EL0 */
        else if (key == SYSREG(1, 3, 14, 0, 2)) val = c->steps;                     /* CNTVCT_EL0 */
        else if (key == SYSREG(1, 3, 14, 0, 0)) val = 19200000;                     /* CNTFRQ_EL0 */
        else if (key == SYSREG(1, 3, 0, 0, 1)) val = 0x8444C004ull;                 /* CTR_EL0 */
        else if (key == SYSREG(1, 3, 0, 0, 7)) val = 0x10;                          /* DCZID_EL0 (dc zva prohibido) */
        else if (key == SYSREG(1, 3, 4, 4, 0) || key == SYSREG(1, 3, 4, 4, 1)) val = 0; /* FPCR / FPSR */
        else if (key == SYSREG(1, 3, 4, 2, 0)) val = ((uint64_t)c->n << 31) | ((uint64_t)c->z << 30) | ((uint64_t)c->c << 29) | ((uint64_t)c->v << 28);
        else known = false;
        if (!known) { fail(c, "registro de sistema no soportado en 0x%llx (insn %08x)", pc, i); return false; }
        if (read) wr_zr(c, rd, slot ? *slot : val);
        else if (slot && slot != &c->tpidrro) *slot = rd_zr(c, rd);
        else if (key == SYSREG(1, 3, 4, 2, 0)) { uint64_t v = rd_zr(c, rd); c->n = (v >> 31) & 1; c->z = (v >> 30) & 1; c->c = (v >> 29) & 1; c->v = (v >> 28) & 1; }
    }
    /* LDR literal (PC-relativo) */
    else if ((i & 0x3F000000u) == 0x18000000u) {
        unsigned opc = (i >> 30) & 3;
        uint64_t addr = pc + (uint64_t)(sext((i >> 5) & 0x7FFFF, 19) * 4);
        if (opc == 3) { /* PRFM literal */ }
        else {
            int size = opc == 0 ? 4 : 8; uint64_t v;
            if (!mem_read(c, addr, size, &v)) return false;
            wr_zr(c, rd, opc == 2 ? (uint64_t)sext(v, 32) : v);
        }
    }
    /* LDXR/STXR/LDAXR/STLXR/LDAR/STLR (un solo nucleo: el monitor siempre tiene exito) */
    else if ((i & 0x3F000000u) == 0x08000000u) {
        unsigned size = (i >> 30) & 3; bool L = (i >> 22) & 1, o1 = (i >> 21) & 1, o2 = (i >> 23) & 1;
        if (o1) { fail(c, "atomico no soportado en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t addr = rd_sp(c, rn);
        if (L) { uint64_t v; if (!mem_read(c, addr, 1 << size, &v)) return false; wr_zr(c, rd, v); }
        else {
            if (!mem_write(c, addr, 1 << size, rd_zr(c, rd))) return false;
            if (!o2) wr_zr(c, rm, 0);  /* estado del STXR: exito */
        }
    }
    /* ADD/SUB extended register */
    else if ((i & 0x1FE00000u) == 0x0B200000u) {
        bool sub = (i >> 30) & 1, S = (i >> 29) & 1;
        unsigned option = (i >> 13) & 7, sh = (i >> 10) & 7;
        if (sh > 4) { fail(c, "ADD/SUB extendido invalido en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t b = trunc_sf(ext_val(rd_zr(c, rm), option, sh), sf);
        uint64_t a = rd_sp(c, rn);
        uint64_t r = sub ? add_with_carry(c, a, ~b, 1, sf, S) : add_with_carry(c, a, b, 0, sf, S);
        if (S) wr_zr(c, rd, r); else wr_sp(c, rd, r);
    }
    /* ADC / SBC (con o sin flags) */
    else if ((i & 0x1FE0FC00u) == 0x1A000000u) {
        bool sub = (i >> 30) & 1, S = (i >> 29) & 1;
        uint64_t b = rd_zr(c, rm); if (sub) b = ~b;
        wr_zr(c, rd, add_with_carry(c, rd_zr(c, rn), b, c->c ? 1 : 0, sf, S));
    }
    /* CCMP / CCMN (registro o inmediato) */
    else if ((i & 0x1FE00410u) == 0x1A400000u) {
        bool is_cmp = (i >> 30) & 1, use_imm = (i >> 11) & 1;
        unsigned cond = (i >> 12) & 15, nzcv = i & 15;
        if (cond_holds(c, cond)) {
            uint64_t b = use_imm ? rm : rd_zr(c, rm);
            if (is_cmp) add_with_carry(c, rd_zr(c, rn), ~b, 1, sf, true);
            else add_with_carry(c, rd_zr(c, rn), b, 0, sf, true);
        } else { c->n = (nzcv >> 3) & 1; c->z = (nzcv >> 2) & 1; c->c = (nzcv >> 1) & 1; c->v = nzcv & 1; }
    }
    /* LSLV / LSRV / ASRV / RORV */
    else if ((i & 0x7FE0F000u) == 0x1AC02000u) {
        unsigned type = (i >> 10) & 3;
        unsigned amt = (unsigned)(rd_zr(c, rm) & (sf ? 63u : 31u));
        wr_zr(c, rd, shift_val(rd_zr(c, rn), type, amt, sf));
    }
    /* RBIT / REV16 / REV32 / REV / CLZ */
    else if ((i & 0x7FFF0000u) == 0x5AC00000u) {
        unsigned op = (i >> 10) & 0x3F; uint64_t v = trunc_sf(rd_zr(c, rn), sf), r = 0;
        unsigned bits = sf ? 64 : 32;
        if (op == 0) { for (unsigned k = 0; k < bits; k++) if ((v >> k) & 1) r |= 1ull << (bits - 1 - k); }
        else if (op == 1) { for (unsigned k = 0; k < bits / 16; k++) { uint64_t h = (v >> (16 * k)) & 0xFFFF; r |= (((h & 0xFF) << 8) | (h >> 8)) << (16 * k); } }
        else if (op == 2 || (op == 3 && sf)) {
            unsigned nbytes = (op == 3) ? 8 : 4;   /* REV (X) = 8 bytes; REV / REV32 = 4 */
            for (unsigned blk = 0; blk < bits / (nbytes * 8); blk++) {
                uint64_t word = (v >> (blk * nbytes * 8)) & (nbytes == 8 ? ~0ull : 0xFFFFFFFFull), out = 0;
                for (unsigned k = 0; k < nbytes; k++) out |= ((word >> (8 * k)) & 0xFF) << (8 * (nbytes - 1 - k));
                r |= out << (blk * nbytes * 8);
            }
        }
        else if (op == 4) { unsigned n = 0; for (int k = (int)bits - 1; k >= 0 && !((v >> k) & 1); k--) n++; r = n; }
        else { fail(c, "operacion de 1 fuente no soportada en 0x%llx (insn %08x)", pc, i); return false; }
        wr_zr(c, rd, trunc_sf(r, sf));
    }
    /* UMULH / SMULH / SMADDL / SMSUBL / UMADDL / UMSUBL */
    else if ((i & 0xFFE0FC00u) == 0x9BC07C00u) {
        wr_zr(c, rd, (uint64_t)(((unsigned __int128)rd_zr(c, rn) * rd_zr(c, rm)) >> 64));
    }
    else if ((i & 0xFFE0FC00u) == 0x9B407C00u) {
        wr_zr(c, rd, (uint64_t)(((__int128)(int64_t)rd_zr(c, rn) * (int64_t)rd_zr(c, rm)) >> 64));
    }
    else if ((i & 0xFF600000u) == 0x9B200000u) {
        bool is_unsigned = (i >> 23) & 1, sub = (i >> 15) & 1; unsigned ra = (i >> 10) & 31;
        uint64_t p = is_unsigned ? (rd_zr(c, rn) & 0xFFFFFFFFull) * (rd_zr(c, rm) & 0xFFFFFFFFull)
                                 : (uint64_t)((int64_t)(int32_t)rd_zr(c, rn) * (int64_t)(int32_t)rd_zr(c, rm));
        wr_zr(c, rd, sub ? rd_zr(c, ra) - p : rd_zr(c, ra) + p);
    }
    /* EXTR (ror inmediato si Rn == Rm) */
    else if ((i & 0x7FA00000u) == 0x13800000u) {
        unsigned lsb = (i >> 10) & 63, bits = sf ? 64 : 32;
        if (lsb >= bits) { fail(c, "EXTR invalido en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t hi = trunc_sf(rd_zr(c, rn), sf), lo = trunc_sf(rd_zr(c, rm), sf);
        wr_zr(c, rd, lsb ? trunc_sf((lo >> lsb) | (hi << (bits - lsb)), sf) : lo);
    }
    /* SVC */
    else if ((i & 0xFFE0001Fu) == 0xD4000001u) { if (c->horizon) do_svc_horizon(c, (i >> 5) & 0xFFFF); else do_syscall(c); }
    /* MOVN / MOVZ / MOVK */
    else if ((i & 0x1F800000u) == 0x12800000u) {
        unsigned opc = (i >> 29) & 3, hw = (i >> 21) & 3;
        uint64_t imm = (uint64_t)((i >> 5) & 0xFFFF) << (hw * 16);
        if (!sf && hw > 1) { fail(c, "MOVx invalido en 0x%llx (insn %08x)", pc, i); return false; }
        if (opc == 0) wr_zr(c, rd, trunc_sf(~imm, sf));
        else if (opc == 2) wr_zr(c, rd, imm);
        else if (opc == 3) {
            uint64_t old = rd_zr(c, rd);
            old &= ~(0xFFFFull << (hw * 16));
            wr_zr(c, rd, trunc_sf(old | imm, sf));
        } else { fail(c, "MOV wide invalido en 0x%llx (insn %08x)", pc, i); return false; }
    }
    /* ADD/SUB inmediato */
    else if ((i & 0x1F000000u) == 0x11000000u) {
        bool sub = (i >> 30) & 1, S = (i >> 29) & 1;
        uint64_t imm = (i >> 10) & 0xFFF;
        if ((i >> 22) & 1) imm <<= 12;
        uint64_t a = rd_sp(c, rn);
        uint64_t r = sub ? add_with_carry(c, a, ~imm, 1, sf, S) : add_with_carry(c, a, imm, 0, sf, S);
        if (S) wr_zr(c, rd, r); else wr_sp(c, rd, r);
    }
    /* ADD/SUB registro con shift */
    else if ((i & 0x1F200000u) == 0x0B000000u) {
        bool sub = (i >> 30) & 1, S = (i >> 29) & 1;
        unsigned type = (i >> 22) & 3, amt = (i >> 10) & 63;
        if (type == 3 || (!sf && amt > 31)) { fail(c, "ADD/SUB invalido en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t b = shift_val(rd_zr(c, rm), type, amt, sf);
        uint64_t a = rd_zr(c, rn);
        uint64_t r = sub ? add_with_carry(c, a, ~b, 1, sf, S) : add_with_carry(c, a, b, 0, sf, S);
        wr_zr(c, rd, r);
    }
    /* AND/ORR/EOR/ANDS registro con shift */
    else if ((i & 0x1F000000u) == 0x0A000000u) {
        unsigned opc = (i >> 29) & 3, type = (i >> 22) & 3, amt = (i >> 10) & 63;
        bool inv = (i >> 21) & 1;
        if (!sf && amt > 31) { fail(c, "logica invalida en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t b = shift_val(rd_zr(c, rm), type, amt, sf);
        if (inv) b = trunc_sf(~b, sf);
        uint64_t a = rd_zr(c, rn), r;
        switch (opc) { case 0: case 3: r = a & b; break; case 1: r = a | b; break; default: r = a ^ b; break; }
        r = trunc_sf(r, sf);
        if (opc == 3) { c->n = (r >> (sf ? 63 : 31)) & 1; c->z = r == 0; c->c = c->v = false; }
        wr_zr(c, rd, r);
    }
    /* SBFM / UBFM (lsl, lsr, asr, ubfx, sxtw...) */
    else if ((i & 0x1F800000u) == 0x13000000u) {
        unsigned opc = (i >> 29) & 3, R = (i >> 16) & 63, S = (i >> 10) & 63;
        unsigned ds = sf ? 64 : 32;
        if (R >= ds || S >= ds) { fail(c, "BFM invalido en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t src = trunc_sf(rd_zr(c, rn), sf), res;
        if (opc == 1) { /* BFM: BFI / BFXIL */
            uint64_t dst = trunc_sf(rd_zr(c, rd), sf);
            unsigned w = (S >= R) ? S - R + 1 : S + 1, sh = (S >= R) ? 0 : ds - R;
            uint64_t m = (w == 64 ? ~0ull : ((1ull << w) - 1));
            uint64_t field = ((S >= R) ? (src >> R) : src) & m;
            wr_zr(c, rd, trunc_sf((dst & ~(m << sh)) | (field << sh), sf));
            goto done_bfm;
        }
        if (S >= R) {
            unsigned w = S - R + 1;
            uint64_t field = (src >> R) & (w == 64 ? ~0ull : ((1ull << w) - 1));
            res = opc == 0 ? (uint64_t)sext(field, w) : field;
        } else {
            unsigned w = S + 1, sh = ds - R;
            uint64_t field = src & ((1ull << w) - 1);
            res = opc == 0 ? (uint64_t)sext(field << sh, w + sh) : (field << sh);
        }
        wr_zr(c, rd, trunc_sf(res, sf));
        done_bfm: ;
    }
    /* MADD / MSUB */
    else if ((i & 0x7FE00000u) == 0x1B000000u) {
        unsigned ra = (i >> 10) & 31;
        uint64_t p = rd_zr(c, rn) * rd_zr(c, rm);
        uint64_t a = rd_zr(c, ra);
        wr_zr(c, rd, trunc_sf(((i >> 15) & 1) ? a - p : a + p, sf));
    }
    /* UDIV / SDIV */
    else if ((i & 0x7FE0F800u) == 0x1AC00800u) {
        bool is_signed = (i >> 10) & 1;
        uint64_t a = trunc_sf(rd_zr(c, rn), sf), b = trunc_sf(rd_zr(c, rm), sf), r;
        if (b == 0) r = 0;
        else if (is_signed) {
            int64_t sa = sext(a, sf ? 64 : 32), sb = sext(b, sf ? 64 : 32);
            r = (sa == INT64_MIN && sb == -1) ? (uint64_t)sa : (uint64_t)(sa / sb);
        } else r = a / b;
        wr_zr(c, rd, trunc_sf(r, sf));
    }
    /* CSEL / CSINC / CSINV / CSNEG */
    else if ((i & 0x1FE00000u) == 0x1A800000u) {
        unsigned op = (i >> 30) & 1, o2 = (i >> 10) & 1, cond = (i >> 12) & 15;
        uint64_t r;
        if (cond_holds(c, cond)) r = rd_zr(c, rn);
        else {
            r = rd_zr(c, rm);
            if (op == 0 && o2 == 1) r += 1;
            else if (op == 1 && o2 == 0) r = ~r;
            else if (op == 1 && o2 == 1) r = (~r) + 1;
        }
        wr_zr(c, rd, trunc_sf(r, sf));
    }
    /* ADR / ADRP */
    else if ((i & 0x1F000000u) == 0x10000000u) {
        int64_t imm = sext((((i >> 5) & 0x7FFFF) << 2) | ((i >> 29) & 3), 21);
        wr_zr(c, rd, sf ? (pc & ~0xFFFull) + (uint64_t)(imm << 12) : pc + (uint64_t)imm);
    }
    /* B / BL */
    else if ((i & 0x7C000000u) == 0x14000000u) {
        if (sf) c->x[30] = next;
        next = pc + (uint64_t)(sext(i & 0x3FFFFFF, 26) * 4);
    }
    /* BR / BLR / RET */
    else if ((i & 0xFFFFFC1Fu) == 0xD61F0000u || (i & 0xFFFFFC1Fu) == 0xD63F0000u || (i & 0xFFFFFC1Fu) == 0xD65F0000u) {
        uint64_t target = rd_zr(c, rn);
        if ((i & 0xFFFFFC1Fu) == 0xD63F0000u) c->x[30] = next;
        next = target;
    }
    /* B.cond */
    else if ((i & 0xFF000010u) == 0x54000000u) {
        if (cond_holds(c, i & 15)) next = pc + (uint64_t)(sext((i >> 5) & 0x7FFFF, 19) * 4);
    }
    /* CBZ / CBNZ */
    else if ((i & 0x7E000000u) == 0x34000000u) {
        bool nz = (i >> 24) & 1;
        uint64_t v = trunc_sf(rd_zr(c, rd), sf);
        if ((v == 0) != nz) next = pc + (uint64_t)(sext((i >> 5) & 0x7FFFF, 19) * 4);
    }
    /* TBZ / TBNZ */
    else if ((i & 0x7E000000u) == 0x36000000u) {
        bool nz = (i >> 24) & 1;
        unsigned bit = (((i >> 31) & 1) << 5) | ((i >> 19) & 31);
        bool set = (rd_zr(c, rd) >> bit) & 1;
        if (set == nz) next = pc + (uint64_t)(sext((i >> 5) & 0x3FFF, 14) * 4);
    }
    /* LDR/STR (enteros) inmediato sin signo */
    else if ((i & 0x3F000000u) == 0x39000000u) {
        unsigned size = (i >> 30) & 3, opc = (i >> 22) & 3;
        uint64_t addr = rd_sp(c, rn) + (((i >> 10) & 0xFFF) << size);
        if (!ldst(c, size, opc, rd, addr, pc, i)) return false;
    }
    /* LDR/STR pre/post-index y sin escalar */
    else if ((i & 0x3F200000u) == 0x38000000u) {
        unsigned size = (i >> 30) & 3, opc = (i >> 22) & 3, idx = (i >> 10) & 3;
        int64_t imm = sext((i >> 12) & 0x1FF, 9);
        if (idx == 2) { fail(c, "LDR/STR variante no soportada en 0x%llx (insn %08x)", pc, i); return false; }
        uint64_t base = rd_sp(c, rn), addr = (idx == 1) ? base : base + (uint64_t)imm;
        if (!ldst(c, size, opc, rd, addr, pc, i)) return false;
        if (idx == 1 || idx == 3) wr_sp(c, rn, base + (uint64_t)imm);
    }
    /* LDR/STR registro (LSL / UXTW / SXTW / SXTX) */
    else if ((i & 0x3F200C00u) == 0x38200800u) {
        unsigned size = (i >> 30) & 3, opc = (i >> 22) & 3, option = (i >> 13) & 7;
        bool S = (i >> 12) & 1;
        if (option != 2 && option != 3 && option != 6 && option != 7) {
            fail(c, "LDR/STR registro no soportado en 0x%llx (insn %08x)", pc, i); return false;
        }
        uint64_t off = rd_zr(c, rm);
        if (option == 2) off &= 0xFFFFFFFFull;
        else if (option == 6) off = (uint64_t)sext(off, 32);
        off <<= S ? size : 0;
        uint64_t addr = rd_sp(c, rn) + off;
        if (!ldst(c, size, opc, rd, addr, pc, i)) return false;
    }
    /* LDP / STP */
    else if ((i & 0x3E000000u) == 0x28000000u && !((i >> 26) & 1)) {
        unsigned opc = (i >> 30) & 3, type = (i >> 23) & 7;
        bool load = (i >> 22) & 1;
        unsigned rt2 = (i >> 10) & 31;
        if (opc == 1 || opc == 3 || type == 0) { fail(c, "LDP/STP no soportado en 0x%llx (insn %08x)", pc, i); return false; }
        int sz = opc == 2 ? 8 : 4;
        int64_t imm = sext((i >> 15) & 0x7F, 7) * sz;
        uint64_t base = rd_sp(c, rn), addr = (type == 1) ? base : base + (uint64_t)imm;
        if (load) {
            uint64_t a, b;
            if (!mem_read(c, addr, sz, &a) || !mem_read(c, addr + (uint64_t)sz, sz, &b)) return false;
            wr_zr(c, rd, a); wr_zr(c, rt2, b);
        } else {
            if (!mem_write(c, addr, sz, rd_zr(c, rd)) || !mem_write(c, addr + (uint64_t)sz, sz, rd_zr(c, rt2))) return false;
        }
        if (type == 1 || type == 3) wr_sp(c, rn, base + (uint64_t)imm);
    }
    else { fail(c, "instruccion desconocida en 0x%llx (insn %08x)", pc, i); return false; }

    if (c->halted) return false;
    c->pc = next;
    return true;
}

void cpu_run(Cpu *cpu, uint64_t max_steps) {
    while (!cpu->halted && (max_steps == 0 || cpu->steps < max_steps)) cpu_step(cpu);
}

void cpu_run_frame(Cpu *cpu, uint64_t step_budget) {
    cpu->frame_ready = false;
    uint64_t limit = cpu->steps + step_budget;
    while (!cpu->halted && !cpu->frame_ready && cpu->steps < limit) cpu_step(cpu);
}

const char *cpu_error(const Cpu *cpu) { return cpu->error; }

const uint8_t *cpu_mem_ptr(const Cpu *cpu, uint64_t addr, size_t len) {
    if (addr < cpu->base || addr - cpu->base > cpu->mem_size || len > cpu->mem_size - (addr - cpu->base)) return NULL;
    return cpu->mem + (addr - cpu->base);
}
