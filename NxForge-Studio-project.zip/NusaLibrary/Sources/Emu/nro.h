#ifndef NUSA_NRO_H
#define NUSA_NRO_H
#include "cpu.h"

/* Memoria virtual que usa el modo homebrew: la imagen se carga en NRO_BASE. */
#define NRO_BASE      0x08000000ull
#define NRO_MEM_SIZE  (64u << 20)

/* Carga un .nro (formato NRO0 de Switch) en una CPU ya inicializada con
 * cpu_init(cpu, NRO_MEM_SIZE, NRO_BASE). Deja pc, sp, x0/x1, TLS y heap listos.
 * Devuelve false y escribe el motivo en err si el archivo no es valido. */
/* Acceso desde Swift (las macros con sufijo ull no siempre se importan). */
static inline uint64_t nro_base(void) { return NRO_BASE; }
static inline size_t nro_mem_size(void) { return (size_t)NRO_MEM_SIZE; }

bool nro_load(Cpu *cpu, const uint8_t *file, size_t len, const char *path, char *err, size_t errlen);

#endif
