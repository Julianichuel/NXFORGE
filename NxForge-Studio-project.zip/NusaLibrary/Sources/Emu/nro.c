#include "nro.h"
#include <stdio.h>
#include <string.h>

static uint32_t rd32(const uint8_t *p) { uint32_t v; memcpy(&v, p, 4); return v; }
static void wr32(uint8_t *p, uint32_t v) { memcpy(p, &v, 4); }
static void wr64(uint8_t *p, uint64_t v) { memcpy(p, &v, 8); }
static uint64_t align_up(uint64_t v, uint64_t a) { return (v + a - 1) & ~(a - 1); }

static bool seg_ok(uint32_t off, uint32_t size, uint32_t image) {
    return off <= image && size <= image - off;
}

/* Entradas del "loader config" de hbl (cada una: u32 clave, u32 flags, u64 valor[2]).
 * Los numeros de clave salen de mi recuerdo del ABI de libnx; no los pude verificar aqui. */
enum { EN_END = 0, EN_MAIN_THREAD = 1, EN_ARGV = 5, EN_SYSCALL_HINT = 6, EN_APPLET_TYPE = 7,
       EN_PROCESS_HANDLE = 10, EN_LAST_LOAD_RESULT = 11, EN_RANDOM_SEED = 14, EN_HOS_VERSION = 16 };

static uint8_t *put_entry(uint8_t *p, uint32_t key, uint64_t v0, uint64_t v1) {
    wr32(p, key); wr32(p + 4, 0); wr64(p + 8, v0); wr64(p + 16, v1);
    return p + 24;
}

bool nro_load(Cpu *cpu, const uint8_t *f, size_t len, const char *path, char *err, size_t errlen) {
#define FAIL(msg) do { snprintf(err, errlen, "%s", msg); return false; } while (0)
    if (len < 0x80) FAIL("archivo demasiado chico para ser un .nro");
    if (rd32(f + 0x10) != 0x304F524Eu) FAIL("no es un .nro (falta la firma NRO0)");
    uint32_t image = rd32(f + 0x18);
    uint32_t text_off = rd32(f + 0x20), text_sz = rd32(f + 0x24);
    uint32_t ro_off = rd32(f + 0x28), ro_sz = rd32(f + 0x2C);
    uint32_t data_off = rd32(f + 0x30), data_sz = rd32(f + 0x34);
    uint32_t bss_sz = rd32(f + 0x38);
    if (image < 0x80 || image > len) FAIL("tamano de imagen invalido en la cabecera");
    if (!seg_ok(text_off, text_sz, image) || !seg_ok(ro_off, ro_sz, image) || !seg_ok(data_off, data_sz, image))
        FAIL("segmentos fuera de la imagen");
    if (text_off != 0) FAIL("el segmento .text no empieza en 0");

    uint64_t image_end = align_up((uint64_t)data_off + data_sz + bss_sz, 0x1000);
    if (image_end < image) image_end = align_up(image, 0x1000);
    uint64_t cfg_off = image_end, tls_off = cfg_off + 0x1000, stack_off = tls_off + 0x1000;
    uint64_t stack_size = 1u << 20, heap_off = stack_off + stack_size;
    if (heap_off + (1u << 20) > cpu->mem_size) FAIL("el .nro es demasiado grande para la memoria virtual");

    memset(cpu->mem, 0, (size_t)heap_off);
    memcpy(cpu->mem, f, image);
    memset(cpu->mem + (uint64_t)data_off + data_sz, 0, bss_sz);   /* .bss en cero */

    /* loader config */
    uint8_t *cfg = cpu->mem + cfg_off, *p = cfg;
    uint64_t strs = cfg_off + 0x400;
    size_t plen = strlen(path); if (plen > 0x200) plen = 0x200;
    memcpy(cpu->mem + strs, path, plen);
    p = put_entry(p, EN_MAIN_THREAD, 0xD000, 0);
    p = put_entry(p, EN_ARGV, 0, cpu->base + strs);
    p = put_entry(p, EN_SYSCALL_HINT, ~0ull, ~0ull);
    p = put_entry(p, EN_APPLET_TYPE, 0, 0);
    p = put_entry(p, EN_PROCESS_HANDLE, 0xD001, 0);
    p = put_entry(p, EN_LAST_LOAD_RESULT, 0, 0);
    p = put_entry(p, EN_RANDOM_SEED, 0x9E3779B97F4A7C15ull, 0xC2B2AE3D27D4EB4Full);
    p = put_entry(p, EN_HOS_VERSION, (16u << 16), 0);
    put_entry(p, EN_END, 0, 0);

    /* si el programa retorna de _start, cae en `svc #7` (ExitProcess) */
    uint64_t exit_stub = cfg_off + 0x300;
    wr32(cpu->mem + exit_stub, 0xD40000E1u);

    cpu->horizon = true;
    cpu->pc = cpu->base;
    cpu->tpidr = 0;
    cpu->tpidrro = cpu->base + tls_off;
    cpu->stack_base = cpu->base + stack_off;
    cpu->stack_size = stack_size;
    cpu->sp = cpu->base + stack_off + stack_size;
    cpu->heap_base = cpu->base + heap_off;
    cpu->heap_size = 0;
    cpu->heap_max = cpu->mem_size - heap_off;
    for (int k = 0; k < 31; k++) cpu->x[k] = 0;
    cpu->x[0] = cpu->base + cfg_off;
    cpu->x[1] = ~0ull;
    cpu->x[30] = cpu->base + exit_stub;
    cpu->steps = 0; cpu->halted = false; cpu->error[0] = 0;
    return true;
#undef FAIL
}
