import SwiftUI
import QuartzCore
import CoreGraphics

/// Envuelve el nucleo de CPU ARM64 (C) y presenta su framebuffer como imagen.
@MainActor
final class Emulator: ObservableObject {
    @Published private(set) var image: CGImage?
    @Published private(set) var running = false
    @Published private(set) var fps = 0
    @Published private(set) var message = "Detenido"

    private var cpu: UnsafeMutablePointer<Cpu>?
    private var link: CADisplayLink?
    private var lastTick = CACurrentMediaTime()
    private var framesThisSecond = 0
    private var secondStart = CACurrentMediaTime()
    private let stepBudget: UInt64 = 3_000_000
    private let w = DemoProgram.width, h = DemoProgram.height

    func start() {
        stop()
        let p = UnsafeMutablePointer<Cpu>.allocate(capacity: 1)
        guard cpu_init(p, 1 << 20, 0x10000) else { message = "Sin memoria"; p.deallocate(); return }
        let ok = DemoProgram.plasma.withUnsafeBufferPointer { cpu_load(p, $0.baseAddress, $0.count, 0) }
        guard ok else { message = "No se pudo cargar el programa"; cpu_free(p); p.deallocate(); return }
        cpu = p
        running = true
        message = "Ejecutando programa ARM64"
        framesThisSecond = 0
        secondStart = CACurrentMediaTime()
        let l = CADisplayLink(target: DisplayTarget { [weak self] in self?.tick() }, selector: #selector(DisplayTarget.fire))
        l.preferredFrameRateRange = CAFrameRateRange(minimum: 30, maximum: 60, preferred: 60)
        l.add(to: .main, forMode: .common)
        link = l
    }

    func stop() {
        link?.invalidate(); link = nil
        if let p = cpu { cpu_free(p); p.deallocate(); cpu = nil }
        if running { message = "Detenido" }
        running = false
        fps = 0
    }

    private func tick() {
        guard let p = cpu else { return }
        cpu_run_frame(p, stepBudget)
        if p.pointee.halted {
            let err = String(cString: cpu_error(p))
            message = err.isEmpty ? "El programa termino (codigo \(p.pointee.exit_code))" : "Error: \(err)"
            stop(); return
        }
        guard p.pointee.frame_ready,
              let ptr = cpu_mem_ptr(p, DemoProgram.framebufferAddress, w * h * 4) else { return }
        let data = Data(bytes: ptr, count: w * h * 4)
        guard let provider = CGDataProvider(data: data as CFData) else { return }
        let info = CGBitmapInfo.byteOrder32Little.union(CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipFirst.rawValue))
        image = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                        space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: info, provider: provider,
                        decode: nil, shouldInterpolate: false, intent: .defaultIntent)
        framesThisSecond += 1
        let now = CACurrentMediaTime()
        if now - secondStart >= 1 { fps = framesThisSecond; framesThisSecond = 0; secondStart = now }
    }

    var steps: UInt64 { cpu?.pointee.steps ?? 0 }

    deinit {
        // El enlace se invalida en stop(); si la vista desaparece sin llamarlo, liberamos aqui.
    }
}

/// Objetivo de CADisplayLink (necesita ser NSObject).
private final class DisplayTarget: NSObject {
    let block: () -> Void
    init(_ block: @escaping () -> Void) { self.block = block }
    @objc func fire() { block() }
}

struct EmulatorScreen: View {
    @StateObject private var emu = Emulator()
    let theme: AppTheme

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Rectangle().fill(.black)
                if let img = emu.image {
                    Image(decorative: img, scale: 1)
                        .resizable().interpolation(.none).aspectRatio(CGFloat(DemoProgram.width) / CGFloat(DemoProgram.height), contentMode: .fit)
                } else {
                    VStack(spacing: 8) {
                        Image(systemName: "cpu").font(.largeTitle).foregroundStyle(.secondary)
                        Text("Pulsa Iniciar para correr el programa demo").font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .aspectRatio(CGFloat(DemoProgram.width) / CGFloat(DemoProgram.height), contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(.white.opacity(0.1)))

            HStack {
                Text(emu.message).font(.system(.footnote, design: .monospaced)).foregroundStyle(.secondary).lineLimit(2)
                Spacer(minLength: 8)
                Text("\(emu.fps) FPS").font(.system(.footnote, design: .monospaced).weight(.bold)).foregroundStyle(Palette.green)
            }

            Button { emu.running ? emu.stop() : emu.start() } label: {
                Label(emu.running ? "Detener" : "Iniciar", systemImage: emu.running ? "stop.fill" : "play.fill")
                    .font(.headline).foregroundStyle(.white)
                    .frame(maxWidth: .infinity).padding(.vertical, 14)
                    .background(theme.gradient.opacity(0.85), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(PillButtonStyle())
        }
        .onDisappear { emu.stop() }
    }
}
