import SwiftUI
import QuartzCore
import CoreGraphics
import UniformTypeIdentifiers

/// Recibe la salida del programa invitado (svcOutputDebugString / write).
/// No esta aislado a ningun actor: lo llama la funcion C de forma sincrona dentro de tick().
final class OutputSink {
    private var pending = Data()
    func append(_ bytes: UnsafePointer<UInt8>, _ count: Int) { pending.append(bytes, count: count) }
    func drain() -> String {
        defer { pending.removeAll(keepingCapacity: true) }
        return String(decoding: pending, as: UTF8.self)
    }
    func reset() { pending.removeAll() }
}

/// Callback de C (write_fn). Es una funcion global para que no herede aislamiento de actor.
private func nusaWriteCallback(_ user: UnsafeMutableRawPointer?, _ fd: Int32, _ buf: UnsafePointer<UInt8>?, _ len: Int) {
    guard let user, let buf else { return }
    Unmanaged<OutputSink>.fromOpaque(user).takeUnretainedValue().append(buf, len)
}

/// Envuelve el nucleo de CPU ARM64 (C). Dos modos:
/// - demo: corre un programa propio que dibuja en un framebuffer.
/// - homebrew: carga un .nro de Switch y muestra lo que imprime.
@MainActor
final class Emulator: ObservableObject {
    enum Mode { case demo, homebrew }

    @Published private(set) var image: CGImage?
    @Published private(set) var running = false
    @Published private(set) var fps = 0
    @Published private(set) var message = "Detenido"
    @Published private(set) var output = ""
    @Published private(set) var mode: Mode = .demo

    weak var log: LogStore?

    private var cpu: UnsafeMutablePointer<Cpu>?
    private var link: CADisplayLink?
    private var framesThisSecond = 0
    private var secondStart = CACurrentMediaTime()
    private var stepBudget: UInt64 = 3_000_000
    private let sink = OutputSink()
    private let w = DemoProgram.width, h = DemoProgram.height

    // MARK: - Demo

    func start() {
        stop()
        mode = .demo
        output = ""
        let p = UnsafeMutablePointer<Cpu>.allocate(capacity: 1)
        guard cpu_init(p, 1 << 20, 0x10000) else { message = "Sin memoria"; p.deallocate(); return }
        let ok = DemoProgram.plasma.withUnsafeBufferPointer { cpu_load(p, $0.baseAddress, $0.count, 0) }
        guard ok else { message = "No se pudo cargar el programa"; cpu_free(p); p.deallocate(); return }
        stepBudget = 3_000_000
        cpu = p
        message = "Ejecutando programa ARM64"
        beginLoop()
    }

    // MARK: - Homebrew (.nro)

    func startHomebrew(url: URL) {
        stop()
        mode = .homebrew
        image = nil
        output = ""
        sink.reset()

        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url) else {
            report("No se pudo leer \(url.lastPathComponent)"); return
        }

        let p = UnsafeMutablePointer<Cpu>.allocate(capacity: 1)
        guard cpu_init(p, nro_mem_size(), nro_base()) else {
            message = "Sin memoria"; p.deallocate(); return
        }
        var errBuf = [CChar](repeating: 0, count: 160)
        let errLen = errBuf.count
        let ok: Bool = data.withUnsafeBytes { raw -> Bool in
            guard let base = raw.bindMemory(to: UInt8.self).baseAddress else { return false }
            return nro_load(p, base, data.count, url.path, &errBuf, errLen)
        }
        guard ok else {
            report("No se pudo cargar: \(String(cString: errBuf))")
            cpu_free(p); p.deallocate(); return
        }

        p.pointee.write_fn = nusaWriteCallback
        p.pointee.write_user = Unmanaged.passUnretained(sink).toOpaque()

        stepBudget = 500_000
        cpu = p
        message = "Ejecutando \(url.lastPathComponent)"
        log?.add("Homebrew cargado: \(url.lastPathComponent) (\(data.count) bytes)", .ok)
        beginLoop()
    }

    func report(_ text: String) {
        message = text
        log?.add(text, .error)
    }

    // MARK: - Ciclo

    private func beginLoop() {
        running = true
        framesThisSecond = 0
        secondStart = CACurrentMediaTime()
        let l = CADisplayLink(target: DisplayTarget { [weak self] in self?.tick() }, selector: #selector(DisplayTarget.fire))
        l.preferredFrameRateRange = CAFrameRateRange(minimum: 30, maximum: 60, preferred: 60)
        l.add(to: .main, forMode: .common)
        link = l
    }

    func stop() {
        link?.invalidate(); link = nil
        if let p = cpu { cpu_free(p); p.deallocate(); cpu = nil }
        if running { message = "Detenido" }
        running = false
        fps = 0
    }

    private func drainOutput() {
        let chunk = sink.drain()
        guard !chunk.isEmpty else { return }
        output += chunk
        if output.count > 4000 { output = String(output.suffix(4000)) }
        let text = chunk.trimmingCharacters(in: .whitespacesAndNewlines)
        if !text.isEmpty { log?.add(text) }
    }

    private func tick() {
        guard let p = cpu else { return }
        cpu_run_frame(p, stepBudget)
        if mode == .homebrew { drainOutput() }

        if p.pointee.halted {
            let err = String(cString: cpu_error(p))
            let finished = err.isEmpty
                ? "El programa termino (codigo \(p.pointee.exit_code), \(p.pointee.steps) instrucciones)"
                : "Error: \(err)"
            stop()                       // stop() deja "Detenido"; despues ponemos el motivo real
            message = finished
            log?.add(finished, err.isEmpty ? .ok : .error)
            return
        }

        guard mode == .demo, p.pointee.frame_ready,
              let ptr = cpu_mem_ptr(p, DemoProgram.framebufferAddress, w * h * 4) else { return }
        let data = Data(bytes: ptr, count: w * h * 4)
        guard let provider = CGDataProvider(data: data as CFData) else { return }
        let info = CGBitmapInfo.byteOrder32Little.union(CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipFirst.rawValue))
        image = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                        space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: info, provider: provider,
                        decode: nil, shouldInterpolate: false, intent: .defaultIntent)
        framesThisSecond += 1
        let now = CACurrentMediaTime()
        if now - secondStart >= 1 { fps = framesThisSecond; framesThisSecond = 0; secondStart = now }
    }

    var steps: UInt64 { cpu?.pointee.steps ?? 0 }
}

/// Objetivo de CADisplayLink (necesita ser NSObject).
private final class DisplayTarget: NSObject {
    let block: () -> Void
    init(_ block: @escaping () -> Void) { self.block = block }
    @objc func fire() { block() }
}

struct EmulatorScreen: View {
    @StateObject private var emu = Emulator()
    @EnvironmentObject private var log: LogStore
    @State private var showNroPicker = false
    let theme: AppTheme

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Rectangle().fill(.black)
                if emu.mode == .homebrew {
                    ScrollView {
                        Text(emu.output.isEmpty ? "Sin salida todavia..." : emu.output)
                            .font(.system(.footnote, design: .monospaced))
                            .foregroundStyle(emu.output.isEmpty ? Color.secondary : Palette.green)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(12)
                    }
                } else if let img = emu.image {
                    Image(decorative: img, scale: 1)
                        .resizable().interpolation(.none).aspectRatio(CGFloat(DemoProgram.width) / CGFloat(DemoProgram.height), contentMode: .fit)
                } else {
                    VStack(spacing: 8) {
                        Image(systemName: "cpu").font(.largeTitle).foregroundStyle(.secondary)
                        Text("Inicia el demo o abre un homebrew .nro").font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            .aspectRatio(CGFloat(DemoProgram.width) / CGFloat(DemoProgram.height), contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(.white.opacity(0.1)))

            HStack {
                Text(emu.message).font(.system(.footnote, design: .monospaced)).foregroundStyle(.secondary).lineLimit(2)
                Spacer(minLength: 8)
                if emu.mode == .demo {
                    Text("\(emu.fps) FPS").font(.system(.footnote, design: .monospaced).weight(.bold)).foregroundStyle(Palette.green)
                }
            }

            if emu.running {
                actionButton("Detener", icon: "stop.fill") { emu.stop() }
            } else {
                actionButton("Iniciar demo", icon: "play.fill") { emu.start() }
                actionButton("Abrir homebrew (.nro)", icon: "doc.badge.gearshape") { showNroPicker = true }
            }
        }
        .onAppear { emu.log = log }
        .onDisappear { emu.stop() }
        .fileImporter(isPresented: $showNroPicker,
                      allowedContentTypes: [UTType(filenameExtension: "nro") ?? .data, .data],
                      allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first { emu.startHomebrew(url: url) }
            case .failure(let error):
                emu.report(error.localizedDescription)
            }
        }
    }

    private func actionButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.headline).foregroundStyle(.white)
                .frame(maxWidth: .infinity).padding(.vertical, 14)
                .background(theme.gradient.opacity(0.85), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(PillButtonStyle())
    }
}
