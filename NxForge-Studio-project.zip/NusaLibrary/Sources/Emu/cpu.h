#ifndef NUSA_CPU_H
#define NUSA_CPU_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

typedef struct Cpu Cpu;
typedef void (*WriteFn)(void *user, int fd, const uint8_t *buf, size_t len);

struct Cpu {
    uint64_t x[31];
    uint64_t sp, pc;
    bool n, z, c, v;
    uint8_t *mem;
    size_t mem_size;
    uint64_t base;          /* direccion virtual del byte 0 de mem */
    bool halted;
    int64_t exit_code;
    char error[96];         /* no vacio si hubo fallo */
    uint64_t steps;
    bool frame_ready;       /* el invitado pidio mostrar un cuadro (syscall 200) */
    WriteFn write_fn;
    void *write_user;
};

/* Reserva memoria, deja pc en el inicio y sp al final. */
bool cpu_init(Cpu *cpu, size_t mem_size, uint64_t base);
void cpu_free(Cpu *cpu);
bool cpu_load(Cpu *cpu, const uint8_t *code, size_t len, uint64_t offset);
/* Ejecuta una instruccion. Devuelve false si se detuvo (exit o error). */
bool cpu_step(Cpu *cpu);
/* Ejecuta hasta detenerse o hasta max_steps (0 = sin limite). */
void cpu_run(Cpu *cpu, uint64_t max_steps);
/* Ejecuta hasta que el invitado presente un cuadro, se detenga, o se agote el presupuesto de pasos. */
void cpu_run_frame(Cpu *cpu, uint64_t step_budget);
/* Utilidades para Swift. */
const char *cpu_error(const Cpu *cpu);
const uint8_t *cpu_mem_ptr(const Cpu *cpu, uint64_t addr, size_t len);

#endif
