import SwiftUI
import UniformTypeIdentifiers

private enum ImportMode { case keys, folder }
private enum Tab: Hashable { case games, emulator, convert, console }
private enum LogFilter: String, CaseIterable { case all = "Todo", ok = "Correcto", info = "Info", error = "Errores" }

struct ContentView: View {
    @EnvironmentObject private var log: LogStore
    @EnvironmentObject private var keys: KeyStore
    @EnvironmentObject private var library: GameLibrary
    @Environment(\.horizontalSizeClass) private var sizeClass

    @AppStorage("themeID") private var themeID = "swirl"
    @State private var tab: Tab = .games
    @State private var filter: LogFilter = .all
    @State private var importMode: ImportMode = .keys
    @State private var showImporter = false
    @State private var showInspect = false
    @State private var search = ""

    private var theme: AppTheme { AppTheme.byID(themeID) }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Palette.bgTop, Palette.bgBottom], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            ScrollView {
                if sizeClass == .regular {
                    HStack(alignment: .top, spacing: 16) {
                        VStack(spacing: 16) { header; statusPills; hero }.frame(maxWidth: .infinity)
                        explorer.frame(maxWidth: .infinity)
                    }
                    .padding(16)
                } else {
                    VStack(spacing: 16) { header; statusPills; hero; explorer }.padding(16)
                }
            }
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: importMode == .folder ? [.folder] : [.item],
                      allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                if importMode == .keys { keys.importKeys(from: url) } else { library.setFolder(url) }
            case .failure(let error):
                log.add("Selector de archivos: \(error.localizedDescription)", .error)
            }
        }
        .sheet(isPresented: $showInspect) { InspectSheet(theme: theme).environmentObject(keys) }
    }

    // MARK: Cabecera

    private var header: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .center, spacing: 14) {
                Image("AppLogo")
                    .resizable().scaledToFit()
                    .frame(width: 64, height: 64)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(.white.opacity(0.12)))
                VStack(alignment: .leading, spacing: 4) {
                    Text("NxForge Studio").font(.title.bold()).lineLimit(1).minimumScaleFactor(0.7)
                    Text("Consola Deck \u{2022} \(theme.name)").font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            Text("GESTOR \u{2022} KEYS + JUEGOS")
                .font(.system(.footnote, design: .monospaced).weight(.bold))
                .foregroundStyle(Palette.blue)
                .padding(.horizontal, 12).padding(.vertical, 7)
                .background(Palette.blue.opacity(0.16), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    headerButton("Inspeccionar", icon: "doc.text.magnifyingglass") { showInspect = true }
                    headerButton("Reescanear", icon: "arrow.triangle.2.circlepath") { library.rescan() }
                    ThemeDots(themeID: $themeID)
                }
            }
        }
        .card(theme)
    }

    private func headerButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) { Image(systemName: icon); Text(title).font(.subheadline.weight(.semibold)) }
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background(Palette.field.opacity(0.8), in: Capsule())
        }
        .buttonStyle(PillButtonStyle())
    }

    // MARK: Estado

    private var statusPills: some View {
        VStack(spacing: 10) {
            switch keys.status {
            case .missing: StatusPill(icon: "key.fill", title: "prod.keys", detail: "Falta", color: Palette.amber)
            case .incomplete(let n): StatusPill(icon: "key.fill", title: "prod.keys", detail: "Incompleto (\(n))", color: Palette.red)
            case .ready(let n): StatusPill(icon: "checkmark.seal.fill", title: "prod.keys", detail: "Activo (\(n))", color: Palette.amber)
            }
            StatusPill(icon: "folder.fill", title: "Carpeta", detail: library.folderName ?? "Sin elegir", color: Palette.blue)
            StatusPill(icon: "externaldrive.fill", title: formatBytes(library.totalBytes), detail: "Almacenamiento", color: Palette.red)
            StatusPill(icon: "gamecontroller.fill", title: "\(library.games.count) juegos", detail: isReady ? "Listo" : "En espera",
                       color: isReady ? Palette.green : .gray)
        }
    }

    // MARK: Tarjeta principal

    private var stepsDone: Int {
        var n = 0
        if case .ready = keys.status { n += 1 }
        if library.folderName != nil { n += 1 }
        if !library.games.isEmpty { n += 1 }
        if isReady { n += 1 }
        return n
    }
    private var isReady: Bool {
        if case .ready = keys.status { return !library.games.isEmpty }
        return false
    }
    private var progressMessage: String {
        if case .ready = keys.status {} else { return "Falta importar un prod.keys completo" }
        if library.folderName == nil { return "Elige la carpeta con tus juegos" }
        if library.games.isEmpty { return "No se encontraron .nsp / .xci en la carpeta" }
        return "Todo listo"
    }

    private var hero: some View {
        VStack(spacing: 14) {
            Button { importMode = .folder; showImporter = true } label: {
                HStack(spacing: 14) {
                    Image(systemName: "bolt.fill").font(.system(size: 30, weight: .bold))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Cargar juegos").font(.title3.bold())
                        Text("Selecciona una carpeta con .nsp / .xci").font(.subheadline).opacity(0.9)
                    }
                    Spacer(minLength: 0)
                }
                .foregroundStyle(.white)
                .padding(18)
                .background(theme.gradient.opacity(0.85), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .buttonStyle(PillButtonStyle())

            HStack(spacing: 12) {
                tile(title: "Importar keys", subtitle: "Elegir prod.keys", icon: "key.horizontal.fill", color: Palette.amber) {
                    importMode = .keys; showImporter = true
                }
                ShareLink(item: log.asText.isEmpty ? "Sin eventos" : log.asText) {
                    tileLabel(title: "Compartir registro", subtitle: "Exportar consola", icon: "square.and.arrow.up.fill", color: Palette.green)
                }
                .buttonStyle(PillButtonStyle())
            }

            if keys.status != .missing {
                Button(role: .destructive) { keys.remove() } label: {
                    Label("Eliminar keys importadas", systemImage: "trash").font(.footnote.weight(.semibold))
                }
            }

            VStack(spacing: 10) {
                HStack {
                    Text(progressMessage).font(.subheadline.weight(.semibold))
                        .foregroundStyle(isReady ? Palette.green : Palette.amber)
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 8)
                    Text("\(stepsDone * 25)%").font(.title3.bold().monospacedDigit()).foregroundStyle(.white.opacity(0.9))
                }
                ProgressView(value: Double(stepsDone), total: 4)
                    .tint(isReady ? Palette.green : Palette.amber)
                HStack(spacing: 8) {
                    ForEach(Array(["1. Keys", "2. Carpeta", "3. Juegos", "4. Listo"].enumerated()), id: \.offset) { idx, label in
                        Text(label).font(.footnote.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.7)
                            .frame(maxWidth: .infinity).padding(.vertical, 9)
                            .foregroundStyle(idx < stepsDone ? .white : .secondary)
                            .background(idx < stepsDone ? theme.a.opacity(0.35) : Palette.field.opacity(0.8), in: Capsule())
                    }
                }
            }
            .padding(14)
            .background(.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .card(theme)
    }

    private func tile(title: String, subtitle: String, icon: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) { tileLabel(title: title, subtitle: subtitle, icon: icon, color: color) }
            .buttonStyle(PillButtonStyle())
    }

    private func tileLabel(title: String, subtitle: String, icon: String, color: Color) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.title2).foregroundStyle(color)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.bold)).lineLimit(1).minimumScaleFactor(0.75)
                Text(subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            .foregroundStyle(.white)
            Spacer(minLength: 0)
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .background(color.opacity(0.14), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    // MARK: Juegos / Consola

    private var explorer: some View {
        VStack(spacing: 14) {
            ScrollView(.horizontal, showsIndicators: false) {
              HStack(spacing: 10) {
                tabButton("Juegos (\(library.games.count))", icon: "gamecontroller.fill", selected: tab == .games) { tab = .games }
                tabButton("Emulador", icon: "cpu", selected: tab == .emulator) { tab = .emulator }
                tabButton("Convertir", icon: "arrow.triangle.2.circlepath", selected: tab == .convert) { tab = .convert }
                tabButton("Consola", icon: "terminal.fill", selected: tab == .console) { tab = .console }
                Spacer(minLength: 0)
                Button { library.rescan() } label: {
                    Image(systemName: "arrow.clockwise").font(.headline)
                        .frame(width: 46, height: 46).background(Palette.field.opacity(0.8), in: Circle())
                }
                .buttonStyle(PillButtonStyle())
                .disabled(library.folderName == nil)
              }
            }
            switch tab {
            case .games: gamesList
            case .emulator: EmulatorScreen(theme: theme)
            case .convert: ConvertScreen(theme: theme)
            case .console: consoleView
            }
        }
        .card(theme)
    }

    private func tabButton(_ title: String, icon: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) { Image(systemName: icon); Text(title).font(.subheadline.weight(.semibold)).lineLimit(1) }
                .foregroundStyle(selected ? .black : .white.opacity(0.9))
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background(selected ? AnyShapeStyle(Palette.blue) : AnyShapeStyle(Palette.field.opacity(0.8)), in: Capsule())
        }
        .buttonStyle(PillButtonStyle())
    }

    private var filteredGames: [GameFile] {
        search.isEmpty ? library.games : library.games.filter { $0.name.localizedCaseInsensitiveContains(search) }
    }

    private var gamesList: some View {
        VStack(spacing: 10) {
            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Buscar juego", text: $search).textInputAutocapitalization(.never).autocorrectionDisabled()
            }
            .padding(12)
            .background(Palette.field.opacity(0.8), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            if library.isScanning {
                ProgressView("Escaneando...").padding(.vertical, 28)
            } else if filteredGames.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "tray").font(.largeTitle).foregroundStyle(.secondary)
                    Text(library.folderName == nil ? "Elige una carpeta para ver tus juegos" : "Sin juegos para mostrar")
                        .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 28)
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(filteredGames) { game in
                        HStack(spacing: 12) {
                            Text(game.ext.uppercased())
                                .font(.system(.caption2, design: .monospaced).weight(.bold))
                                .padding(.horizontal, 8).padding(.vertical, 5)
                                .background(theme.a.opacity(0.2), in: Capsule()).foregroundStyle(theme.a)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(game.name).font(.subheadline.weight(.semibold)).lineLimit(2)
                                Text(formatBytes(game.size)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(12)
                        .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                }
            }
        }
    }

    private var visibleLines: [LogStore.Line] {
        switch filter {
        case .all: return log.lines
        case .ok: return log.lines.filter { $0.level == .ok }
        case .info: return log.lines.filter { $0.level == .info }
        case .error: return log.lines.filter { $0.level == .error }
        }
    }

    private var consoleView: some View {
        VStack(spacing: 12) {
            HStack {
                Text("Telemetr\u{00ED}a \u{2022} \(visibleLines.count)/\(log.lines.count) l\u{00ED}neas")
                    .font(.system(.footnote, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.7)
                Spacer(minLength: 0)
                smallButton("Limpiar", icon: "trash") { log.clear() }
                smallButton("Copiar", icon: "doc.on.doc") { UIPasteboard.general.string = log.asText }
            }
            HStack(spacing: 8) {
                ForEach(LogFilter.allCases, id: \.self) { f in
                    Button { filter = f } label: {
                        Text(f.rawValue).font(.footnote.weight(.bold)).lineLimit(1).minimumScaleFactor(0.7)
                            .frame(maxWidth: .infinity).padding(.vertical, 10)
                            .foregroundStyle(filter == f ? .black : .white.opacity(0.85))
                            .background(filter == f ? AnyShapeStyle(Palette.blue) : AnyShapeStyle(Palette.field.opacity(0.8)), in: Capsule())
                    }
                    .buttonStyle(PillButtonStyle())
                }
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 6) {
                    if visibleLines.isEmpty { Text("Sin actividad reciente").foregroundStyle(.secondary) }
                    ForEach(visibleLines) { line in
                        Text(prefix(line.level) + line.text)
                            .foregroundStyle(color(line.level))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .font(.system(.footnote, design: .monospaced))
                .padding(14)
            }
            .frame(height: 260)
            .background(.black.opacity(0.5), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }

    private func smallButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) { Image(systemName: icon); Text(title).font(.footnote.weight(.semibold)) }
                .padding(.horizontal, 12).padding(.vertical, 9)
                .background(Palette.field.opacity(0.8), in: Capsule())
        }
        .buttonStyle(PillButtonStyle())
    }

    private func prefix(_ l: LogStore.Level) -> String {
        switch l { case .info: return "[INFO] "; case .ok: return "[OK] "; case .error: return "[ROJO] " }
    }
    private func color(_ l: LogStore.Level) -> Color {
        switch l { case .info: return .white.opacity(0.85); case .ok: return Palette.green; case .error: return Palette.red }
    }
}

/// Muestra que keys base estan presentes (sin mostrar nunca los valores).
struct InspectSheet: View {
    @EnvironmentObject private var keys: KeyStore
    @Environment(\.dismiss) private var dismiss
    let theme: AppTheme

    var body: some View {
        NavigationStack {
            List {
                Section("Estado") {
                    switch keys.status {
                    case .missing: Label("No hay prod.keys importado", systemImage: "xmark.octagon.fill").foregroundStyle(Palette.amber)
                    case .incomplete(let n): Label("Incompleto: \(n) keys", systemImage: "exclamationmark.triangle.fill").foregroundStyle(Palette.red)
                    case .ready(let n): Label("Completo: \(n) keys", systemImage: "checkmark.seal.fill").foregroundStyle(Palette.green)
                    }
                }
                Section("Keys base") {
                    ForEach(keys.requiredChecklist, id: \.name) { item in
                        HStack {
                            Text(item.name).font(.system(.footnote, design: .monospaced))
                            Spacer()
                            Image(systemName: item.present ? "checkmark.circle.fill" : "circle")
                                .foregroundStyle(item.present ? Palette.green : .secondary)
                        }
                    }
                }
            }
            .navigationTitle("Inspeccionar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }
}
