import SwiftUI
import Foundation

struct GameFile: Identifiable, Hashable {
    let id: URL
    let name: String
    let ext: String
    let size: Int64
    var url: URL { id }
}

/// Elige una carpeta desde Archivos y lista los juegos que hay dentro.
@MainActor
final class GameLibrary: ObservableObject {
    @Published private(set) var games: [GameFile] = []
    @Published private(set) var folderName: String?
    @Published private(set) var isScanning = false
    private var log: LogStore?
    private let bookmarkKey = "libraryFolderBookmark"
    private let extensions: Set<String> = ["nsp", "xci", "nsz", "xcz"]

    var totalBytes: Int64 { games.reduce(0) { $0 + $1.size } }

    func attach(log: LogStore) {
        guard self.log == nil else { return }
        self.log = log
        if let data = UserDefaults.standard.data(forKey: bookmarkKey) {
            var stale = false
            if let url = try? URL(resolvingBookmarkData: data, bookmarkDataIsStale: &stale) {
                scan(url)
            }
        }
    }

    func setFolder(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        if let data = try? url.bookmarkData() {
            UserDefaults.standard.set(data, forKey: bookmarkKey)
        }
        scan(url)
    }

    func rescan() {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }
        var stale = false
        if let url = try? URL(resolvingBookmarkData: data, bookmarkDataIsStale: &stale) { scan(url) }
    }

    private func scan(_ url: URL) {
        isScanning = true
        folderName = url.lastPathComponent
        let exts = extensions
        Task {
            let found: [GameFile] = await Task.detached(priority: .userInitiated) {
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                var out: [GameFile] = []
                let keys: [URLResourceKey] = [.fileSizeKey, .isRegularFileKey]
                guard let e = FileManager.default.enumerator(at: url, includingPropertiesForKeys: keys,
                                                             options: [.skipsHiddenFiles]) else { return out }
                for case let file as URL in e {
                    let ext = file.pathExtension.lowercased()
                    guard exts.contains(ext) else { continue }
                    let size = (try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                    out.append(GameFile(id: file, name: file.deletingPathExtension().lastPathComponent,
                                        ext: ext, size: Int64(size)))
                }
                return out.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            }.value
            games = found
            isScanning = false
            log?.add("Carpeta \"\(url.lastPathComponent)\": \(found.count) archivo(s) encontrado(s).", found.isEmpty ? .info : .ok)
        }
    }
}

func formatBytes(_ b: Int64) -> String {
    ByteCountFormatter.string(fromByteCount: b, countStyle: .file)
}
