import SwiftUI

@main
struct NusaLibraryApp: App {
    @StateObject private var log = LogStore()
    @StateObject private var keys = KeyStore()
    @StateObject private var library = GameLibrary()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(log)
                .environmentObject(keys)
                .environmentObject(library)
                .preferredColorScheme(.dark)
                .onAppear {
                    keys.attach(log: log)
                    library.attach(log: log)
                }
        }
    }
}
