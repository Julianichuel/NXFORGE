#!/bin/sh
# Pruebas del nucleo de CPU y del cargador de .nro (Linux o macOS, sin dependencias).
set -e
cd "$(dirname "$0")"
CC=${CC:-cc}
$CC -O1 -g -Wall -Wextra -Wno-missing-field-initializers -o /tmp/nusa_test_cpu tests/test_cpu.c Sources/Emu/cpu.c
/tmp/nusa_test_cpu
python3 tests/make_nro.py /tmp/nusa_hello.nro
$CC -O1 -g -Wall -Wextra -o /tmp/nusa_test_nro tests/test_nro.c Sources/Emu/cpu.c Sources/Emu/nro.c
/tmp/nusa_test_nro /tmp/nusa_hello.nro
