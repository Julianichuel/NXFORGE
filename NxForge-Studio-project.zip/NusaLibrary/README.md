# NxForge Studio

App SwiftUI (iOS 16+) con:
- Gestor: importar `prod.keys` (solo valida el formato), elegir carpeta de Archivos, listar .nsp/.xci/.nsz/.xcz.
- Emulador (base): nucleo de CPU ARM64 en C (`Sources/Emu/cpu.c`). Dos usos:
  - Demo: un programa propio (plasma 160x120) que dibuja en un framebuffer.
  - Homebrew: boton "Abrir homebrew (.nro)". Carga un .nro de Switch (`Sources/Emu/nro.c`), le da pila,
    TLS, heap y un loader config, y atiende un subconjunto de SVC de Horizon. Lo que el programa imprime
    con svcOutputDebugString aparece en pantalla y en la Consola.
  Todavia NO corre juegos de Switch ni homebrew grande (faltan SIMD/FP, servicios IPC como sm:/vi/hid, GPU).

## Estado de las pruebas (`./run_tests.sh`)
- 55 pruebas de instrucciones y SVC, y 14 del cargador de .nro, pasan en Linux.
- Se prueban con opcodes escritos a mano y un .nro sintetico (`tests/make_nro.py`); no hay un homebrew real
  ni un ensamblador ARM64 en el entorno de pruebas. El codigo Swift no se pudo compilar fuera de GitHub Actions.
- 4 temas de color (Swirl, Joy-Blue, Crimson, Amber).

## Generar el .ipa SIN Mac
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Pestana **Actions** -> "Build IPA (sin firmar)" -> **Run workflow**.
3. Al terminar, descarga el artefacto `NxForge-Studio-ipa` (contiene `NxForge-Studio.ipa`).
4. Firmalo/instalalo con tu metodo habitual (SideStore, AltStore, etc.).

## Con Mac
    brew install xcodegen && xcodegen
    open NusaLibrary.xcodeproj   # elige tu equipo en Signing y ejecuta

## Probar el nucleo de CPU en Linux/Mac
En la carpeta NusaEmu: `./run_tests.sh`


## Convertir NSP a IPA (pestana "Convertir")
La conversion la hace nxnative (fork para iPhones anteriores) en una Mac de GitHub Actions; la app solo la controla:
1. Pide el trabajo a GitHub con `build-game-ipa.yml` (los enlaces del juego viajan cifrados con tu contrasena).
2. Sigue los pasos en vivo, descarga el resultado cifrado y lo descifra en el telefono.
3. Deja el `.ipa` en Archivos > En mi iPhone > NxForge Studio y lo ofrece para compartir con SideStore.

Requisitos: secretos `PROD_KEYS_B64` y `ARTIFACT_PASSWORD` en el repo, un token de GitHub con permiso Actions (lectura y escritura),
enlaces directos a tu NSP, y espacio libre en el iPhone (~2 veces el tamano del IPA).

Sin verificar: que la maquina de GitHub tenga el Xcode y el disco que pide nxnative, que el resultado quepa en un artefacto,
y que el juego corra en el iPhone. Ver `probar-entorno.yml` para la prueba previa sin juegos.
