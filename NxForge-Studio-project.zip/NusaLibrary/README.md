# NxForge Studio

App SwiftUI (iOS 16+) con:
- Gestor: importar `prod.keys` (solo valida el formato), elegir carpeta de Archivos, listar .nsp/.xci/.nsz/.xcz.
- Emulador (base): nucleo de CPU ARM64 en C (`Sources/Emu/cpu.c`) que ejecuta un programa nativo ARM64
  (demo plasma 160x120) y muestra su framebuffer. Todavia NO corre juegos de Switch.
- 4 temas de color (Swirl, Joy-Blue, Crimson, Amber).

## Generar el .ipa SIN Mac
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Pestana **Actions** -> "Build IPA (sin firmar)" -> **Run workflow**.
3. Al terminar, descarga el artefacto `NxForge-Studio-ipa` (contiene `NxForge-Studio.ipa`).
4. Firmalo/instalalo con tu metodo habitual (SideStore, AltStore, etc.).

## Con Mac
    brew install xcodegen && xcodegen
    open NusaLibrary.xcodeproj   # elige tu equipo en Signing y ejecuta

## Probar el nucleo de CPU en Linux/Mac
En la carpeta NusaEmu: `./run_tests.sh`
