#!/usr/bin/env python3
"""Genera tests/hello.nro: un NRO sintetico minimo (sin libnx) para probar el cargador."""
import struct, sys

def movz(rd, imm, hw=0, x=True): return (0xD2800000 if x else 0x52800000) | (hw << 21) | (imm << 5) | rd
def adr(rd, delta):  # delta en bytes desde el PC de esta instruccion
    imm = delta & 0x1FFFFF
    return 0x10000000 | ((imm & 3) << 29) | ((imm >> 2) << 5) | rd
def svc(n): return 0xD4000001 | (n << 5)

TEXT, RO, DATA, BSS = 0x1000, 0x1000, 0x1000, 0x1000
msg = b"Hola desde NRO"
code, pc0 = [], 0x80
def emit(w): code.append(w & 0xFFFFFFFF)
def here(): return pc0 + 4 * len(code)

emit(0xAA0003F3)                                  # mov x19, x0   (puntero al loader config)
emit(adr(0, 0x1000 - here()))                     # adr x0, msg (en .rodata)
emit(movz(1, len(msg)))                           # mov x1, #len
emit(svc(0x27))                                   # svcOutputDebugString
emit(movz(1, 1, hw=1))                            # mov x1, #0x10000
emit(svc(0x01))                                   # svcSetHeapSize -> x1 = base del heap
emit(movz(2, 0xCAFE))                             # mov x2, #0xCAFE
emit(0xF9000022)                                  # str x2, [x1]
emit(0xF9400023)                                  # ldr x3, [x1]
emit(adr(4, (TEXT + RO + DATA) - here()))         # adr x4, inicio del .bss
emit(0xF9400085)                                  # ldr x5, [x4]   (debe ser 0)
emit(0xD53BD066)                                  # mrs x6, tpidrro_el0
emit(0xF94000C7)                                  # ldr x7, [x6]   (TLS en cero)
emit(0xB9400268)                                  # ldr w8, [x19]  (clave de la 1a entrada del config)
emit(movz(1, 6))                                  # mov x1, #6 (TotalMemorySize)
emit(svc(0x29))                                   # svcGetInfo
emit(0xAA0103E9)                                  # mov x9, x1
emit(svc(0x07))                                   # svcExitProcess

image = bytearray(TEXT + RO + DATA)
struct.pack_into("<I", image, 0x00, 0x14000000 | (0x80 // 4))   # b startup
struct.pack_into("<I", image, 0x04, 0)                           # offset de MOD0 (no usado)
hdr = struct.pack("<4sIIIIIIIIII", b"NRO0", 0, len(image), 0, 0, TEXT, TEXT, RO, TEXT + RO, DATA, BSS)
image[0x10:0x10 + len(hdr)] = hdr
for k, w in enumerate(code): struct.pack_into("<I", image, pc0 + 4 * k, w)
image[TEXT:TEXT + len(msg)] = msg
image[TEXT + RO:TEXT + RO + 8] = b"\xAA" * 8                     # datos no nulos en .data

open(sys.argv[1] if len(sys.argv) > 1 else "hello.nro", "wb").write(image)
