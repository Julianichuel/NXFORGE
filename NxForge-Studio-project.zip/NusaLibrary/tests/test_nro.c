#include "../Sources/Emu/nro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char out[256]; static size_t out_len;
static void sink(void *u, int fd, const uint8_t *b, size_t n) { (void)u; (void)fd; if (out_len + n < sizeof out) { memcpy(out + out_len, b, n); out_len += n; } }
static int fails = 0, total = 0;
static void expect(const char *n, int ok) { total++; if (!ok) { fails++; printf("FAIL %s\n", n); } }

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    FILE *f = fopen(argv[1], "rb"); if (!f) { perror("abrir"); return 2; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *buf = malloc((size_t)n); if (fread(buf, 1, (size_t)n, f) != (size_t)n) return 2; fclose(f);

    Cpu cpu; char err[128] = "";
    expect("init", cpu_init(&cpu, NRO_MEM_SIZE, NRO_BASE));
    expect("nro_load ok", nro_load(&cpu, buf, (size_t)n, "sdmc:/switch/hello.nro", err, sizeof err));
    if (err[0]) printf("  err: %s\n", err);
    cpu.write_fn = sink;
    cpu_run(&cpu, 100000);
    expect("termina por ExitProcess sin error", cpu.halted && !cpu.error[0]);
    expect("imprime por svcOutputDebugString", out_len == 14 && !memcmp(out, "Hola desde NRO", 14));
    expect("heap: escribir y leer", cpu.x[3] == 0xCAFE);
    expect("bss en cero", cpu.x[5] == 0);
    expect("TLS en cero y accesible", cpu.x[7] == 0);
    expect("config: primera clave = MainThreadHandle", cpu.x[8] == 1);
    expect("svcGetInfo TotalMemorySize", cpu.x[9] == NRO_MEM_SIZE);
    expect("hubo 4 SVC", cpu.svc_count == 4);
    expect("sp alineado", (cpu.sp & 15) == 0);
    cpu_free(&cpu);

    /* archivos invalidos */
    Cpu c2; cpu_init(&c2, NRO_MEM_SIZE, NRO_BASE);
    uint8_t bad[0x100] = {0};
    expect("rechaza archivo corto", !nro_load(&c2, bad, 0x20, "x", err, sizeof err));
    expect("rechaza sin firma NRO0", !nro_load(&c2, bad, sizeof bad, "x", err, sizeof err));
    memcpy(bad + 0x10, "NRO0", 4); uint32_t big = 0x7FFFFFFF; memcpy(bad + 0x18, &big, 4);
    expect("rechaza tamano de imagen invalido", !nro_load(&c2, bad, sizeof bad, "x", err, sizeof err));
    cpu_free(&c2); free(buf);
    printf("%d pruebas del cargador, %d fallos\n", total, fails);
    return fails ? 1 : 0;
}
