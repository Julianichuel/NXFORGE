/* Pruebas de las instrucciones y SVC agregadas. Compilar: ver run_tests.sh */
#include "../Sources/Emu/cpu.h"
#include <stdio.h>
#include <string.h>

#define DATA 0x20000ull   /* direccion de datos (base 0x10000, memoria 1MB) */
static int fails = 0, total = 0;

typedef struct { uint64_t x[8]; bool n, z, c, v; } Init;

static Cpu cpu;
static void fresh(void) { if (cpu.mem) cpu_free(&cpu); cpu_init(&cpu, 1 << 20, 0x10000); }
static char out_buf[256]; static size_t out_len;
static void sink(void *u, int fd, const uint8_t *b, size_t n) { (void)u; (void)fd; if (out_len + n < sizeof out_buf) { memcpy(out_buf + out_len, b, n); out_len += n; } }

static void run(const uint32_t *code, size_t words, uint64_t steps, const Init *in, bool horizon) {
    fresh();
    cpu_load(&cpu, (const uint8_t *)code, words * 4, 0);
    if (in) { for (int k = 0; k < 8; k++) cpu.x[k] = in->x[k]; cpu.n = in->n; cpu.z = in->z; cpu.c = in->c; cpu.v = in->v; }
    cpu.horizon = horizon;
    cpu.heap_base = 0x80000; cpu.heap_max = 0x10000; cpu.stack_base = 0x90000; cpu.stack_size = 0x1000;
    out_len = 0; cpu.write_fn = sink;
    cpu_run(&cpu, steps);
}
static void check(const char *name, bool ok, uint64_t got, uint64_t want) {
    total++;
    if (ok) return;
    fails++; printf("FAIL %s: obtuve 0x%llx, esperaba 0x%llx (err='%s')\n", name, (unsigned long long)got, (unsigned long long)want, cpu.error);
}
#define EXPECT_X(name, reg, want) check(name, cpu.x[reg] == (uint64_t)(want) && !cpu.error[0], cpu.x[reg], (uint64_t)(want))
#define EXPECT_FLAGS(name, N, Z, C, V) check(name, cpu.n == (N) && cpu.z == (Z) && cpu.c == (C) && cpu.v == (V), (cpu.n<<3)|(cpu.z<<2)|(cpu.c<<1)|cpu.v, ((N)<<3)|((Z)<<2)|((C)<<1)|(V))
static void poke(uint64_t addr, uint64_t v, int n) { memcpy(cpu.mem + (addr - cpu.base), &v, (size_t)n); }

int main(void) {
    Init in;

    /* --- cargas con extension de signo --- */
    memset(&in, 0, sizeof in); in.x[1] = DATA;
    #define RUN_MEM(code, val, nbytes, steps, nm, reg, want) do { uint32_t w[1] = { code }; fresh(); cpu_load(&cpu, (uint8_t *)w, 4, 0); \
        poke(DATA, val, nbytes); cpu.x[1] = DATA; cpu_run(&cpu, steps); EXPECT_X(nm, reg, want); } while (0)
    RUN_MEM(0xB9800020, 0xFFFFFFFEull, 4, 1, "ldrsw x0", 0, 0xFFFFFFFFFFFFFFFEull);
    RUN_MEM(0x39C00020, 0x80, 1, 1, "ldrsb w0", 0, 0xFFFFFF80ull);
    RUN_MEM(0x39800020, 0x80, 1, 1, "ldrsb x0", 0, 0xFFFFFFFFFFFFFF80ull);
    RUN_MEM(0x79800020, 0x8000, 2, 1, "ldrsh x0", 0, 0xFFFFFFFFFFFF8000ull);
    RUN_MEM(0x79C00020, 0x8000, 2, 1, "ldrsh w0", 0, 0xFFFF8000ull);

    /* --- LDR literal --- */
    { uint32_t w[4] = { 0x58000040, 0xD503201F, 0x55667788, 0x11223344 };
      memset(&in, 0, sizeof in); run(w, 4, 1, &in, false); EXPECT_X("ldr x0,literal", 0, 0x1122334455667788ull); }
    { uint32_t w[4] = { 0x18000040, 0xD503201F, 0x55667788, 0x11223344 };
      run(w, 4, 1, &in, false); EXPECT_X("ldr w0,literal", 0, 0x55667788ull); }
    { uint32_t w[4] = { 0x98000040, 0xD503201F, 0x80000000, 0 };
      run(w, 4, 1, &in, false); EXPECT_X("ldrsw x0,literal", 0, 0xFFFFFFFF80000000ull); }

    /* --- CLZ / RBIT / REV --- */
    #define RUN1(code, x1v, x2v, nm, want) do { uint32_t w[1] = { code }; memset(&in, 0, sizeof in); in.x[1] = (x1v); in.x[2] = (x2v); run(w, 1, 1, &in, false); EXPECT_X(nm, 0, want); } while (0)
    RUN1(0xDAC01020, 1ull << 40, 0, "clz x", 23);
    RUN1(0xDAC01020, 0, 0, "clz x (0)", 64);
    RUN1(0x5AC01020, 0, 0, "clz w (0)", 32);
    RUN1(0x5AC01020, 0x00010000, 0, "clz w", 15);
    RUN1(0x5AC00020, 1, 0, "rbit w", 0x80000000ull);
    RUN1(0xDAC00020, 1, 0, "rbit x", 1ull << 63);
    RUN1(0xDAC00C20, 0x0102030405060708ull, 0, "rev x", 0x0807060504030201ull);
    RUN1(0x5AC00820, 0x01020304, 0, "rev w", 0x04030201ull);
    RUN1(0x5AC00420, 0x01020304, 0, "rev16 w", 0x02010403ull);
    RUN1(0xDAC00820, 0x0102030405060708ull, 0, "rev32 x", 0x0403020108070605ull);

    /* --- desplazamientos por registro --- */
    RUN1(0x9AC22020, 1, 65, "lslv x (amt&63)", 2);
    RUN1(0x9AC22420, 0x80, 4, "lsrv x", 8);
    RUN1(0x9AC22820, 0x8000000000000000ull, 63, "asrv x", ~0ull);
    RUN1(0x9AC22C20, 1, 1, "rorv x", 1ull << 63);

    /* --- multiplicaciones --- */
    RUN1(0x9BC27C20, ~0ull, 2, "umulh", 1);
    RUN1(0x9B427C20, ~0ull, ~0ull, "smulh (-1*-1)", 0);
    RUN1(0x9B427C20, ~0ull, 2, "smulh (-1*2)", ~0ull);
    RUN1(0x9B227C20, 0xFFFFFFFFull, 3, "smull", (uint64_t)-3);
    RUN1(0x9BA27C20, 0xFFFFFFFFull, 2, "umull", 0x1FFFFFFFEull);

    /* --- ADD extendido --- */
    RUN1(0x8B224020, 0x100, 0xFFFFFFFF00000004ull, "add x,x,w uxtw", 0x104);
    RUN1(0x8B22C820, 0, 0x80000000ull, "add x,x,w sxtw #2", 0xFFFFFFFE00000000ull);

    /* --- ADC / SBC --- */
    { uint32_t w[1] = { 0x9A020020 }; memset(&in, 0, sizeof in); in.x[1] = 5; in.x[2] = 6; in.c = true; run(w, 1, 1, &in, false); EXPECT_X("adc (c=1)", 0, 12); }
    { uint32_t w[1] = { 0xDA020020 }; memset(&in, 0, sizeof in); in.x[1] = 10; in.x[2] = 3; in.c = false; run(w, 1, 1, &in, false); EXPECT_X("sbc (c=0)", 0, 6); }
    { uint32_t w[1] = { 0xDA020020 }; in.c = true; run(w, 1, 1, &in, false); EXPECT_X("sbc (c=1)", 0, 7); }

    /* --- CCMP --- */
    { uint32_t w[1] = { 0xFA410004 }; memset(&in, 0, sizeof in); in.x[0] = 5; in.x[1] = 5; in.z = true; run(w, 1, 1, &in, false); EXPECT_FLAGS("ccmp eq (cond ok, 5==5)", false, true, true, false); }
    { uint32_t w[1] = { 0xFA410004 }; in.z = false; run(w, 1, 1, &in, false); EXPECT_FLAGS("ccmp eq (cond falla -> nzcv=4)", false, true, false, false); }
    { uint32_t w[1] = { 0xFA410800 }; memset(&in, 0, sizeof in); in.x[0] = 5; in.z = false; run(w, 1, 1, &in, false); EXPECT_FLAGS("ccmp imm (cond falla -> 0)", false, false, false, false); }

    /* --- EXTR / ROR imm --- */
    RUN1(0x93C12020, 1, 0, "ror x,#8", 0x0100000000000000ull);
    RUN1(0x93C22020, 0xAA, 0xBB00, "extr x,#8", 0xAA000000000000BBull);

    /* --- BFM --- */
    { uint32_t w[1] = { 0xB3781C20 }; memset(&in, 0, sizeof in); in.x[0] = ~0ull; in.x[1] = 0xAB; run(w, 1, 1, &in, false); EXPECT_X("bfi x0,x1,#8,#8", 0, 0xFFFFFFFFFFFFABFFull); }
    { uint32_t w[1] = { 0xB3483C20 }; memset(&in, 0, sizeof in); in.x[0] = 0xFF00; in.x[1] = 0xAB00; run(w, 1, 1, &in, false); EXPECT_X("bfxil x0,x1,#8,#8", 0, 0xFFABull); }

    /* --- exclusivos y barreras --- */
    { uint32_t w[8] = { 0xC85F7C20, 0xC8027C23, 0xD5033BBF, 0xD5033FDF, 0xD5033F9F, 0xD503203F, 0xC8DFFC20, 0xC89FFC20 };
      memset(&in, 0, sizeof in); in.x[1] = DATA; in.x[3] = 0x9999; in.x[2] = 0xFF;
      fresh(); cpu_load(&cpu, (uint8_t *)w, sizeof w, 0); poke(DATA, 0x1234, 8);
      cpu.x[1] = DATA; cpu.x[3] = 0x9999; cpu.x[2] = 0xFF; cpu_run(&cpu, 2);
      EXPECT_X("ldxr", 0, 0x1234); EXPECT_X("stxr estado", 2, 0);
      uint64_t m; memcpy(&m, cpu.mem + (DATA - cpu.base), 8); check("stxr escribe", m == 0x9999, m, 0x9999);
      cpu_run(&cpu, 7); check("barreras/hints sin error", !cpu.error[0], 0, 0);
      EXPECT_X("ldar", 0, 0x9999); }

    /* --- registros de sistema --- */
    { uint32_t w[4] = { 0xD53BD060, 0xD51BD041, 0xD53BD042, 0xD53BE003 };
      fresh(); cpu_load(&cpu, (uint8_t *)w, sizeof w, 0); cpu.tpidrro = 0x1234; cpu.x[1] = 0xABCD; cpu_run(&cpu, 4);
      EXPECT_X("mrs tpidrro", 0, 0x1234); EXPECT_X("msr/mrs tpidr", 2, 0xABCD); EXPECT_X("mrs cntfrq", 3, 19200000); }

    /* --- SVC de Horizon --- */
    { uint32_t w[2] = { 0xD2840001, 0xD4000021 }; /* mov x1,#0x2000 ; svc #1 */
      memset(&in, 0, sizeof in); run(w, 2, 2, &in, true); EXPECT_X("svcSetHeapSize res", 0, 0); EXPECT_X("svcSetHeapSize addr", 1, 0x80000); check("heap_size", cpu.heap_size == 0x2000, cpu.heap_size, 0x2000); }
    { uint32_t w[3] = { 0xD2A00201, 0xD2800000, 0xD4000021 }; /* mov x1,#0x100000 (excede heap_max) ... */
      memset(&in, 0, sizeof in); run(w, 3, 3, &in, true); EXPECT_X("svcSetHeapSize excede", 0, 0xD001); }
    { uint32_t w[3] = { 0xD2800081, 0xD4000001 | (0x27 << 5), 0xD40000E1 }; /* mov x1,#4 ; svc #0x27 ; svc #7 */
      fresh(); cpu.horizon = true; cpu.write_fn = sink; out_len = 0;
      memcpy(cpu.mem + 0x1000, "hola", 4);
      cpu_load(&cpu, (uint8_t *)w, sizeof w, 0); cpu.x[0] = 0x11000; cpu_run(&cpu, 0);
      check("svcOutputDebugString", out_len == 4 && !memcmp(out_buf, "hola", 4) && cpu.halted && !cpu.error[0], out_len, 4); }
    { uint32_t w[2] = { 0xD28000C1, 0xD4000001 | (0x29 << 5) }; /* x1=6 ; svc #0x29 */
      memset(&in, 0, sizeof in); run(w, 2, 2, &in, true); EXPECT_X("svcGetInfo TotalMemory", 1, 1 << 20); }
    { uint32_t w[1] = { 0xD4000001 | (0x77 << 5) };
      memset(&in, 0, sizeof in); run(w, 1, 1, &in, true); check("SVC desconocida detiene con error", cpu.halted && cpu.error[0], cpu.halted, 1); }
    { uint32_t w[1] = { 0xD4000001 | (0x26 << 5) };
      run(w, 1, 1, &in, true); check("svcBreak detiene", cpu.halted && cpu.error[0], cpu.halted, 1); }

    printf("%d pruebas, %d fallos\n", total, fails);
    cpu_free(&cpu);
    return fails ? 1 : 0;
}
